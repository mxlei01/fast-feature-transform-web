"""Declarative transformer shells.

Transformers hold kernel parameters only; fit and transform execute in the
C++ core. After fit, fitted state lives in C++ and the properties here are
read-only views of it.
"""

import itertools
import json
import math
import operator
import os
import tempfile
from collections.abc import Sequence
from pathlib import Path
from typing import Any, ClassVar, Self, overload

from fast_inference import _core


class _ArrowOutput:
    """Transfer an owned C stream to a consumer through Arrow's public protocol."""

    def __init__(self, capsule: object) -> None:
        """Retain the owned capsule until its consumer imports it."""
        self.capsule = capsule

    def __arrow_c_stream__(self, requested_schema: object = None) -> object:
        """Return the output stream capsule, without schema conversion."""
        if requested_schema is not None:
            raise NotImplementedError("Arrow output does not support a requested schema")
        return self.capsule


def _transform_arrow(handle: _core.FittedPipeline, data: Any) -> Any:
    """Transform resident Arrow input and return a PyArrow Table.

    Args:
        handle: The fitted native pipeline.
        data: An Arrow table, record batch, or C stream exporter.

    Returns:
        The transformed PyArrow Table.

    Raises:
        ImportError: If the optional PyArrow dependency is unavailable.
        TypeError: If the input does not export an Arrow C stream.

    """
    try:
        import pyarrow as pa
    except ImportError:
        raise ImportError("transform_arrow requires pyarrow") from None
    if isinstance(data, pa.RecordBatch):
        data = pa.Table.from_batches([data])
    export = getattr(data, "__arrow_c_stream__", None)
    if not callable(export):
        raise TypeError("transform_arrow expects an Arrow table, record batch, or C stream exporter")
    # The C stream cuts a field name at a NUL byte, on the way in and on the
    # way out. When a name holds one, the names go across whole beside the
    # stream: a PyArrow input's to the binding, and the output's back from it.
    # Otherwise both are None. Other producers' names cannot be recovered.
    names = data.schema.names if isinstance(data, (pa.Table, pa.RecordBatchReader)) else None
    if names is not None and "\x00" not in "\x01".join(names):
        names = None  # one join is the cheapest test, about half a microsecond for ten names
    capsule, output_names = handle.transform_arrow(export(), names)
    table = pa.table(_ArrowOutput(capsule))
    return table if output_names is None else table.rename_columns(output_names)


def _cached_manifest(handle: _core.FittedPipeline) -> str:
    """Return a fitted handle's manifest JSON, serialized once per handle.

    Fitted state never changes, so the string is cached on the handle and
    every pipeline or transformer bound to it pickles the very same object,
    which pickle then stores once.

    Args:
        handle: The fitted C++ pipeline.

    Returns:
        The manifest JSON.

    """
    cached: str | None = getattr(handle, "_manifest_cache", None)
    if cached is None:
        cached = handle.manifest_json()
        setattr(handle, "_manifest_cache", cached)  # noqa: B010
    return cached


def _integer(value: Any, what: str) -> int:
    """Accept any integral number (numpy included) except bool.

    Args:
        value: The value to check.
        what: What the value is, for the error message.

    Returns:
        The value as an int.

    Raises:
        TypeError: If the value is a bool or not integral.

    """
    if isinstance(value, bool):
        raise TypeError(f"{what} must be an integer, got {value!r}")
    try:
        return operator.index(value)
    except TypeError:
        raise TypeError(f"{what} must be an integer, got {value!r}") from None


def _source_paths(X: object) -> list[str]:
    """Normalize a batch input to a list of parquet paths.

    Args:
        X: A list (or tuple) of str or path-like parquet file paths.

    Returns:
        The paths as strings, in order.

    Raises:
        TypeError: If X is a single path, or holds anything but paths.

    """
    if isinstance(X, (str, os.PathLike)):
        raise TypeError("X must be a list of parquet paths, not a single path — wrap it in a list")
    if not isinstance(X, (list, tuple)):
        raise TypeError(f"X must be a list of parquet paths, got {type(X).__name__}")
    paths: list[str] = []
    for item in X:
        if not isinstance(item, (str, os.PathLike)):
            raise TypeError(f"X must be a list of parquet paths; element {item!r} is a {type(item).__name__}")
        paths.append(os.fspath(item))
    return paths


def _check_threads(threads: int) -> int:
    """Validate a worker-thread count.

    Args:
        threads: Requested worker threads; 0 means all cores.

    Returns:
        The validated count.

    Raises:
        ValueError: If threads is negative or not an integer.

    """
    try:
        value: int = _integer(threads, "threads")
    except TypeError:
        raise ValueError(f"threads must be an integer >= 0 (0 uses all cores), got {threads!r}") from None
    if value < 0:
        raise ValueError(f"threads must be an integer >= 0 (0 uses all cores), got {threads!r}")
    return value


def _fit_engine(threads: int, temp_dir: str | Path | None) -> _core.Engine:
    """Construct the native engine with an optional spill directory.

    Args:
        threads: Worker count, or zero for all cores.
        temp_dir: Parent directory for private spill files, or the system temp directory.

    Returns:
        A native engine with automatic fit buffering.

    Raises:
        TypeError: If temp_dir is not a string path.
        ValueError: If threads is invalid.

    """
    directory = os.fspath(temp_dir) if temp_dir is not None else ""
    if not isinstance(directory, str):
        raise TypeError("temp_dir must be a string path")
    return _core.Engine(_check_threads(threads), directory)


def _column_list(columns: object, what: str) -> list[str]:
    """Validate a list of column names.

    Args:
        columns: The value passed for a ``columns`` argument.
        what: The transformer name, for the error message.

    Returns:
        The column names as a list.

    Raises:
        TypeError: If columns is a bare string or holds non-strings.
        ValueError: If columns is empty.

    """
    if isinstance(columns, str):
        raise TypeError(f"{what}: columns must be a list of column names, not a single string")
    if not isinstance(columns, (list, tuple)) or not all(isinstance(column, str) for column in columns):
        raise TypeError(f"{what}: columns must be a list of column names, got {columns!r}")
    if not columns:
        raise ValueError(f"{what}: columns must name at least one column")
    return list(columns)


class Transformer:
    """Base shell: declares a kernel and its params; execution lives in C++.

    Attributes:
        kernel_id: The kernel this transformer compiles to.

    """

    kernel_id: ClassVar[str]

    _handle: _core.FittedPipeline | None = None
    _stage: str | None = None
    _standalone: bool = False
    _state_cache: dict[str, Any] | None = None

    def params(self) -> dict[str, Any]:
        """Kernel parameters, serialized verbatim into the plan and artifact.

        Returns:
            The declarative parameter mapping for this kernel.

        """
        raise NotImplementedError

    def fit(
        self,
        X: Sequence[str | Path],
        y: Any = None,
        *,
        threads: int = 0,
        temp_dir: str | Path | None = None,
    ) -> Self:
        """Fit this transformer standalone by wrapping it in a one-stage pipeline.

        A shell is a view of one fitted artifact at a time: fitting it again,
        or fitting a Pipeline that holds it, rebinds it to the newest fit.

        Fit reads Parquet in batches and automatically spills retained exact
        samples when needed. Spilling trades disk space and I/O time for lower
        sample RAM; model tables, batch width and Parquet decoder buffers still
        contribute to process memory. No sampling is introduced.

        Args:
            X: List of parquet file paths.
            y: Ignored; present for sklearn compatibility.
            threads: Worker threads for the engine; 0 uses all cores.
            temp_dir: Existing parent directory for private temporary spill files;
                defaults to the system temp directory. Files are removed after
                fitting or an exception.

        Returns:
            self, fitted.

        Raises:
            EngineError: If the input cannot be read or a column is missing or mistyped.
            TypeError: If X is a single path instead of a list of paths.

        """
        from fast_inference.pipeline import Pipeline

        Pipeline([(type(self).__name__.lower(), self)]).fit(X, y, threads=threads, temp_dir=temp_dir)
        self._standalone = True
        return self

    def transform_dict(self, X: dict[str, Any]) -> dict[str, Any]:
        """Transform a single record through this standalone-fitted transformer.

        Args:
            X: One record as a flat dict of str, int, float, bool, datetime,
                or None values (numpy scalars are converted, and a datetime
                becomes int64 microseconds since 1970-01-01).

        Returns:
            The transformed record.

        Raises:
            EngineError: If a value cannot be converted or a required key is missing.
            RuntimeError: If unfitted, or fitted as part of a Pipeline.

        """
        # The serving path: a record costs a couple of hundred nanoseconds, and
        # the two frames _standalone_handle adds are a large share of that. A
        # shell that is not ready still goes through it, for the error.
        handle: _core.FittedPipeline | None = self._handle
        if handle is None or self._stage is None or not self._standalone:
            handle = self._standalone_handle()
        return handle.transform_row(X)

    def transform_parquet(self, X: Sequence[str | Path], *, output_dir: str | Path | None = None) -> list[Path]:
        """Transform parquet files through this standalone-fitted transformer.

        Args:
            X: List of parquet file paths.
            output_dir: Directory for output part files; a temporary directory
                is created when omitted. Existing ``part-NNNNN.parquet`` files
                in it are replaced once the run starts, and a run that fails
                midway leaves none.

        Returns:
            The list of written part-file paths, ordered by task index.

        Raises:
            EngineError: If the input cannot be read, does not match the fitted schema, or
                has rows while the pipeline emits no columns, which Parquet output
                cannot hold; ``transform_arrow`` and ``transform_dict`` return them.
            RuntimeError: If unfitted, or fitted as part of a Pipeline.
            TypeError: If X is a single path instead of a list of paths.

        """
        handle: _core.FittedPipeline = self._standalone_handle()
        out_dir: str = str(output_dir) if output_dir is not None else tempfile.mkdtemp(prefix="fast_inference_")
        return [Path(path) for path in handle.transform_batch(_source_paths(X), out_dir)]

    def transform_memmap(self, X: Sequence[str | Path], *, output_dir: str | Path) -> Path:
        """Transform Parquet directly into packed training records.

        Args:
            X: Input Parquet files.
            output_dir: Directory for data.mmap and index.json.

        Returns:
            Path to index.json, with the same layout as parquet_to_memmap.

        Raises:
            EngineError: If a result contains nulls or unsupported field types, or
                the pipeline emits no columns.
            RuntimeError: If this transformer does not own a fitted pipeline.

        """
        return Path(self._standalone_handle().transform_memmap(_source_paths(X), str(output_dir)))

    def transform_arrow(self, X: Any) -> Any:
        """Transform resident Arrow input into a PyArrow Table without files.

        Args:
            X: A Table, RecordBatch, or object exporting an Arrow C stream.
                A stream is consumed once. Input buffers are never modified.

        Returns:
            A PyArrow Table owning its output buffers. All output is retained
            in memory; the row and Parquet paths use the same fitted kernels.

        Raises:
            ImportError: If pyarrow is not installed.
            EngineError: If the schema or data violates a kernel's contract.
            RuntimeError: If this transformer does not own a fitted pipeline.

        """
        return _transform_arrow(self._standalone_handle(), X)

    @overload
    def transform(self, X: dict[str, Any]) -> dict[str, Any]: ...

    @overload
    def transform(self, X: Sequence[str | Path], *, output_dir: str | Path | None = None) -> list[Path]: ...

    def transform(
        self, X: dict[str, Any] | Sequence[str | Path], *, output_dir: str | Path | None = None
    ) -> dict[str, Any] | list[Path]:
        """Transform a record dict or a list of parquet paths through this transformer.

        Sklearn-compatible convenience dispatching to transform_dict or
        transform_parquet.

        Args:
            X: A single record dict, or a list of parquet file paths.
            output_dir: Directory for batch output part files; a temporary
                directory is created when omitted.

        Returns:
            A transformed record dict, or the list of written part-file paths.

        Raises:
            EngineError: If the engine rejects the input.
            RuntimeError: If unfitted, or fitted as part of a Pipeline.
            TypeError: If X is neither a dict nor a list of paths.

        """
        if isinstance(X, dict):
            return self.transform_dict(X)
        if isinstance(X, (list, tuple)):
            return self.transform_parquet(X, output_dir=output_dir)
        raise TypeError(f"unsupported input type: {type(X).__name__}; expected dict or list of parquet paths")

    def __repr__(self) -> str:
        """Render the shell as its constructor call.

        Returns:
            ``ClassName(param=value, ...)``.

        """
        arguments: str = ", ".join(f"{key}={value!r}" for key, value in self.params().items())
        return f"{type(self).__name__}({arguments})"

    def _standalone_handle(self) -> _core.FittedPipeline:
        """Return the handle when this transformer owns it exclusively.

        Returns:
            The fitted C++ pipeline handle.

        Raises:
            RuntimeError: If unfitted, or fitted as part of a Pipeline.

        """
        handle: _core.FittedPipeline = self._require_handle()
        if not self._standalone:
            raise RuntimeError(
                f"{type(self).__name__} was fitted as part of a Pipeline; call transform on that pipeline"
            )
        return handle

    def __getstate__(self) -> dict[str, Any]:
        """Pickle the shell, carrying fitted state only when this shell owns it.

        A standalone-fitted transformer embeds its artifact manifest so the
        round trip stays fitted; a pipeline-bound shell pickles unfitted (its
        owning Pipeline's pickle carries the manifest and rebinds on restore).

        Returns:
            The instance dict without the C++ handle, plus the manifest when
            this transformer owns its handle.

        """
        transient: tuple[str, ...] = ("_handle", "_stage", "_standalone", "_state_cache", "_vocab_size_cache")
        state: dict[str, Any] = {key: value for key, value in self.__dict__.items() if key not in transient}
        if self._handle is not None and self._standalone:
            state["_manifest"] = _cached_manifest(self._handle)
            state["_stage_name"] = self._stage
        return state

    def __setstate__(self, state: dict[str, Any]) -> None:
        """Restore the shell, reloading fitted state when the pickle carried it.

        Args:
            state: State dict produced by __getstate__.

        """
        manifest: str | None = state.pop("_manifest", None)
        stage: str | None = state.pop("_stage_name", None)
        self.__dict__.update(state)
        if manifest is not None and stage is not None:
            self._bind(_core.FittedPipeline.load_json(manifest), stage, standalone=True)

    def _bind(self, handle: _core.FittedPipeline, stage: str, *, standalone: bool) -> None:
        """Attach the fitted C++ pipeline handle this transformer belongs to.

        Args:
            handle: The fitted C++ pipeline.
            stage: This transformer's dotted stage name in the plan.
            standalone: Whether this transformer owns the handle outright.

        """
        self._handle = handle
        self._stage = stage
        self._standalone = standalone
        self._state_cache = None

    def _require_handle(self) -> _core.FittedPipeline:
        """Return the fitted handle or raise if this transformer is unfitted.

        Returns:
            The fitted C++ pipeline handle.

        Raises:
            RuntimeError: If the transformer has not been fitted.

        """
        if self._handle is None or self._stage is None:
            raise RuntimeError(f"{type(self).__name__} is not fitted")
        return self._handle

    def _state(self) -> dict[str, Any]:
        """Read this transformer's fitted state from the C++ core (once per binding).

        Returns:
            The fitted state as a plain dict.

        """
        if self._state_cache is None:
            handle = self._require_handle()
            assert self._stage is not None
            self._state_cache = json.loads(handle.stage_state(self._stage))
        return self._state_cache


class Select(Transformer):
    """Column projection: keep exactly the given columns, in order."""

    kernel_id: ClassVar[str] = "select"

    def __init__(self, columns: list[str]) -> None:
        """Initialize the projection.

        Args:
            columns: Columns to keep, in output order.

        Raises:
            TypeError: If columns is a bare string or holds non-strings.
            ValueError: If columns is empty.

        """
        self.columns: list[str] = _column_list(columns, "Select")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the select kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"columns": self.columns}


class LabelEncoder(Transformer):
    """Categorical utf8 -> int64 index; index 0 is reserved for unknown.

    Fit streams a per-category count accumulator over Parquet batches with
    memory proportional to the observed vocabulary. Known categories sort by byte order and take indices 1..n;
    unknown categories, nulls, and categories below ``min_count`` map to 0
    (the ``torch.nn.Embedding(padding_idx=0)`` convention). Both string
    layouts (``string`` and ``large_string``) are supported; categories must
    be valid UTF-8.
    """

    kernel_id: ClassVar[str] = "label_encode"
    _vocab_size_cache: dict[str, int]

    def __init__(self, columns: list[str] | None = None, min_count: int = 1) -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            min_count: Categories seen fewer than this many times are dropped
                (they encode to 0).

        Raises:
            TypeError: If columns is a bare string or min_count is not an integer.
            ValueError: If columns is empty or min_count is below 1.

        """
        self.columns: list[str] | None = None if columns is None else _column_list(columns, "LabelEncoder")
        self.min_count: int = _integer(min_count, "LabelEncoder: min_count")
        if self.min_count < 1:
            raise ValueError(f"LabelEncoder: min_count must be >= 1, got {min_count}")
        self._vocab_size_cache = {}

    def _bind(self, handle: _core.FittedPipeline, stage: str, *, standalone: bool) -> None:
        """Bind fitted state and replace the per-column vocabulary-size cache.

        Args:
            handle: The fitted native pipeline.
            stage: This encoder's stage name.
            standalone: Whether this encoder owns the pipeline handle.

        """
        super()._bind(handle, stage, standalone=standalone)
        self._vocab_size_cache = {}

    def __setstate__(self, state: dict[str, Any]) -> None:
        """Restore the shell with a fresh, transient vocabulary-size cache.

        Args:
            state: The pickled shell state.

        """
        self._vocab_size_cache = {}
        super().__setstate__(state)

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the label_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"columns": self.columns, "min_count": self.min_count}

    @property
    def label_maps_(self) -> dict[str, dict[str, int]]:
        """Fitted category -> index maps, materialized from the C++ core.

        Returns:
            Mapping of column name to its category -> index map.

        """
        return self._state()["label_maps"]

    def vocab_size(self, column: str) -> int:
        """Number of embedding rows needed for a column (len(map) + 1 for unknown).

        Successful queries are cached per column until the encoder is rebound.

        Args:
            column: The encoded column name.

        Returns:
            The vocabulary size including the reserved unknown index 0.

        """
        cache = self._vocab_size_cache
        try:
            return cache[column]
        except KeyError, TypeError:
            pass
        handle = self._require_handle()
        assert self._stage is not None
        if not isinstance(column, str):
            # Preserve Python dict key semantics for unusual invalid arguments.
            return self._state()["vocab_sizes"][column]
        try:
            size = handle.vocab_size(self._stage, column)
        except _core.EngineError:
            # Missing columns historically raised KeyError. Materializing state
            # only on this exceptional path preserves that public behavior.
            return self._state()["vocab_sizes"][column]
        # A concurrent rebind replaces this dict. A query already in progress
        # can only populate the old binding's captured cache.
        cache[column] = size
        return size


TYPE_TAGS: frozenset[str] = frozenset({"utf8", "i8", "i16", "i32", "i64", "u8", "u16", "u32", "u64", "f32", "f64"})


class Cast(Transformer):
    """Explicit per-column type conversion: the only step that changes a column's type.

    Apart from reading datetimes as epoch microseconds, the engine never
    converts a value on its own, so a column whose type does not suit a
    downstream step is converted here, visibly, from a closed table: integers
    to any integer width and floats to any float width (an out-of-range value
    is an error, never a wrap); integers to strings as decimal digits; strings
    to integers or floats, parsed strictly; integers to floats only when
    exact; floats to integers only when whole and in range; bools to
    integers. Floats are never cast to strings, because ``1``
    and ``1.0`` have no single spelling. Nulls pass through. In record mode
    the value's own type is the source; a conversion outside the table is an
    error naming the key.
    """

    kernel_id: ClassVar[str] = "cast"

    def __init__(self, types: dict[str, str]) -> None:
        """Initialize the cast.

        Args:
            types: Mapping of column name to target type tag, one of
                ``utf8``, ``i8``, ``i16``, ``i32``, ``i64``, ``u8``, ``u16``,
                ``u32``, ``u64``, ``f32``, ``f64``.

        Raises:
            TypeError: If types is not a non-empty mapping of names to tags.
            ValueError: If a tag is not one of the supported targets.

        """
        if not isinstance(types, dict) or not types:
            raise TypeError("Cast: types must be a non-empty mapping of column name to type tag")
        for column, tag in types.items():
            if not isinstance(column, str) or not isinstance(tag, str):
                raise TypeError(f"Cast: types must map column names to type tags, got {column!r}: {tag!r}")
            if tag not in TYPE_TAGS:
                raise ValueError(
                    f"Cast: unsupported type {tag!r} for column {column!r}; choose one of {sorted(TYPE_TAGS)}"
                )
        self.types: dict[str, str] = dict(types)

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the cast kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"types": self.types}


def _one_of(value: object, allowed: frozenset[str] | set[str], what: str, option: str) -> str:
    """Validate a string option against the values a kernel accepts.

    Args:
        value: The value passed for the option.
        allowed: The accepted values.
        what: The transformer name, for the error message.
        option: The option name, for the error message.

    Returns:
        The value.

    Raises:
        ValueError: If the value is not one of the accepted ones.

    """
    if value not in allowed:
        raise ValueError(f"{what}: {option} must be one of {sorted(allowed)}, got {value!r}")
    return str(value)


_HANDLE_UNKNOWN: frozenset[str] = frozenset({"value", "return_nan", "error"})
_HANDLE_MISSING: frozenset[str] = frozenset({"value", "return_nan", "error"})

AGGREGATES: frozenset[str] = frozenset({"count", "sum", "mean", "min", "max", "median"})


class GroupAgg(Transformer):
    """Per-key aggregates, fitted once over the training data and looked up at transform.

    ``GroupAgg(key="user_id", aggs={"price": ["mean", "max"], "clicks": ["sum"]})``
    streams the data once, keeping the requested aggregates of each column
    for every key; transform then replaces each aggregated column with one
    column per aggregate, named ``<column>_<agg>`` and appended after the
    remaining columns, looked up by the record's key (the key column
    stays). The key is a utf8 or integer column. ``count`` counts a column's non-null values and applies to any
    column; ``sum``, ``mean``, ``min``, ``max``, and ``median`` need an
    integer or float column and skip its nulls. Types stay explicit:
    ``count`` is i64, ``sum`` is i64 for integer columns (an overflow is an
    error) and f64 for floats, ``mean`` and ``median`` are f64, and ``min``
    and ``max`` keep the column's type. An unknown or null key, and a key
    whose values were all null, yield 0 for every aggregate, like
    LabelEncoder's index 0. The streaming aggregates keep memory proportional
    to the number of keys; ``median`` retains exact values per key in
    automatically spillable storage until their ranks are fitted.
    """

    kernel_id: ClassVar[str] = "group_agg"

    def __init__(self, key: str, aggs: dict[str, list[str] | tuple[str, ...]]) -> None:
        """Initialize the aggregation.

        Args:
            key: The column to group by.
            aggs: Mapping of column name to the aggregates to compute for it,
                each one of ``count``, ``sum``, ``mean``, ``min``, ``max``,
                ``median``.

        Raises:
            TypeError: If key is not a column name or aggs is not a mapping of
                column names to lists of names.
            ValueError: If an aggregate is unknown or listed twice for a column.

        """
        if not isinstance(key, str) or not key:
            raise TypeError(f"GroupAgg: key must be a column name, got {key!r}")
        if not isinstance(aggs, dict) or not aggs:
            raise TypeError("GroupAgg: aggs must be a non-empty mapping of column name to a list of aggregates")
        validated: dict[str, list[str]] = {}
        for column, names in aggs.items():
            if not isinstance(column, str) or not column:
                raise TypeError(f"GroupAgg: aggs keys must be column names, got {column!r}")
            if isinstance(names, str) or not isinstance(names, (list, tuple)) or not names:
                raise TypeError(f"GroupAgg: aggregates for column {column!r} must be a non-empty list, got {names!r}")
            for name in names:
                if not isinstance(name, str) or name not in AGGREGATES:
                    raise ValueError(
                        f"GroupAgg: unknown aggregate {name!r} for column {column!r}; choose from {sorted(AGGREGATES)}"
                    )
            if len(set(names)) != len(names):
                raise ValueError(f"GroupAgg: column {column!r} lists an aggregate more than once")
            validated[column] = list(names)
        self.key: str = key
        self.aggs: dict[str, list[str]] = validated

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the group_agg kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"key": self.key, "aggs": self.aggs}

    @property
    def keys_(self) -> list[Any]:
        """Fitted keys, sorted (strings or integers, matching the key column).

        Returns:
            The keys in table order.

        """
        return self._state()["keys"]

    @property
    def values_(self) -> dict[str, list[Any]]:
        """Fitted aggregates: output column name -> one value per key, in ``keys_`` order.

        Returns:
            Mapping of ``<column>_<agg>`` to its values.

        """
        return self._state()["values"]


class CountEncoder(Transformer):
    """Categorical utf8 -> how often that category was seen at fit.

    The simplest of the category_encoders family and the one whose fitted
    table is a plain tally, so it is exact and never depends on how the rows
    were split across workers. ``normalize=True`` divides each count by the
    fitted row count, making the output f64 instead of i64. A null is a
    countable category under ``handle_missing="value"``, a null under
    ``"return_nan"``, and an error under ``"error"`` — refused at transform
    as well as at fit, as category_encoders does. An unseen category yields 0
    under ``handle_unknown="value"``, that integer when an integer is given,
    a null under ``"return_nan"``, and an error under ``"error"``; an integer
    is the literal number you asked to see, so ``normalize=True`` scales a
    real count and leaves that number alone. A ``min_group_size`` group whose
    name is already a category that survived the fold is a fit-time error
    rather than a silent overwrite.
    """

    kernel_id: ClassVar[str] = "count_encode"

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        normalize: bool = False,
        min_group_size: float | None = None,
        min_group_name: str | None = None,
        combine_min_nan_groups: bool | str = True,
        handle_unknown: str | int = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            normalize: Divide each count by the fitted row count.
            min_group_size: Fold every category below this threshold into one
                group whose count is their sum. A float is a fraction of the
                fitted rows; an integer is a count.
            min_group_name: Name for that group; the members joined with "_"
                in sorted order when omitted.
            combine_min_nan_groups: Whether the null category joins the folded
                group when its count is below min_group_size too; "force"
                folds it whenever there were nulls, and False never does.
            handle_unknown: What an unseen category becomes: "value" (0),
                "return_nan", "error", or an integer to fill with.
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If columns is a bare string or an option has the wrong type.
            ValueError: If an option is not one of the accepted values.

        """
        self.columns: list[str] | None = None if columns is None else _column_list(columns, "CountEncoder")
        if not isinstance(normalize, bool):
            raise TypeError(f"CountEncoder: normalize must be True or False, got {normalize!r}")
        if min_group_size is not None:
            if isinstance(min_group_size, bool) or not isinstance(min_group_size, (int, float)):
                raise TypeError(f"CountEncoder: min_group_size must be a number, got {min_group_size!r}")
            if min_group_size <= 0:
                raise ValueError(f"CountEncoder: min_group_size must be positive, got {min_group_size!r}")
        if min_group_name is not None and not isinstance(min_group_name, str):
            raise TypeError(f"CountEncoder: min_group_name must be a string, got {min_group_name!r}")
        if combine_min_nan_groups not in (True, False, "force"):
            raise ValueError(
                f"CountEncoder: combine_min_nan_groups must be True, False or 'force', got {combine_min_nan_groups!r}"
            )
        if isinstance(handle_unknown, bool) or (
            not isinstance(handle_unknown, int) and handle_unknown not in _HANDLE_UNKNOWN
        ):
            raise ValueError(
                f"CountEncoder: handle_unknown must be an integer or one of {sorted(_HANDLE_UNKNOWN)}, "
                f"got {handle_unknown!r}"
            )
        if handle_missing not in _HANDLE_MISSING:
            raise ValueError(
                f"CountEncoder: handle_missing must be one of {sorted(_HANDLE_MISSING)}, got {handle_missing!r}"
            )
        self.normalize: bool = normalize
        self.min_group_size: float | None = min_group_size
        self.min_group_name: str | None = min_group_name
        self.combine_min_nan_groups: bool | str = combine_min_nan_groups
        self.handle_unknown: str | int = handle_unknown
        self.handle_missing: str = handle_missing

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the count_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "normalize": self.normalize,
            "min_group_size": self.min_group_size,
            "min_group_name": self.min_group_name,
            "combine_min_nan_groups": self.combine_min_nan_groups,
            "handle_unknown": self.handle_unknown,
            "handle_missing": self.handle_missing,
        }

    @property
    def counts_(self) -> dict[str, dict[str, int]]:
        """Fitted category -> count tables, materialized from the C++ core.

        Returns:
            Mapping of column name to its category -> count table.

        """
        return self._state()["counts"]


class OrdinalEncoder(Transformer):
    """Categorical utf8 -> an integer code, in place.

    Categories sort and take the codes ``index_start`` through
    ``index_start + n - 1``. A null seen at fit under
    ``handle_missing="value"`` is a category of its own and takes the code
    after them; a null that was not seen at fit encodes to ``-2``, as
    category_encoders does. An unseen category encodes to ``-1`` under
    ``handle_unknown="value"``, a null under ``"return_nan"``, and an error
    under ``"error"``. An ``index_start`` so large that the highest code
    would not fit in an int64 is a fit-time error, never a wrap into a
    negative embedding index.
    """

    kernel_id: ClassVar[str] = "ordinal_encode"

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        index_start: int = 1,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            index_start: The code the first category takes.
            handle_unknown: What an unseen category becomes: "value" (-1),
                "return_nan", or "error".
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If columns is a bare string or index_start is not an integer.
            ValueError: If an option is not one of the accepted values.

        """
        self.columns: list[str] | None = None if columns is None else _column_list(columns, "OrdinalEncoder")
        self.index_start: int = _integer(index_start, "OrdinalEncoder: index_start")
        self.handle_unknown: str = _one_of(handle_unknown, _HANDLE_UNKNOWN, "OrdinalEncoder", "handle_unknown")
        self.handle_missing: str = _one_of(handle_missing, _HANDLE_MISSING, "OrdinalEncoder", "handle_missing")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the ordinal_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "index_start": self.index_start,
            "handle_unknown": self.handle_unknown,
            "handle_missing": self.handle_missing,
        }

    @property
    def categories_(self) -> dict[str, list[str]]:
        """Fitted categories per column, sorted.

        Returns:
            Mapping of column name to its sorted category list.

        """
        return self._state()["categories"]


class _Expanding(Transformer):
    """Shared shell for the encoders that replace a column with one column per category."""

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        use_cat_names: bool = False,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            use_cat_names: Name the output columns after the categories
                rather than after the codes.
            handle_unknown: What an unseen category becomes: "value" (all
                zeros), "return_nan", "error", or "indicator" for
                OneHotEncoder, which adds a ``<column>_-1`` column.
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If columns is a bare string or use_cat_names is not a bool.
            ValueError: If an option is not one of the accepted values.

        """
        what: str = type(self).__name__
        allowed: frozenset[str] = _HANDLE_UNKNOWN | ({"indicator"} if self.kernel_id == "one_hot_encode" else set())
        self.columns: list[str] | None = None if columns is None else _column_list(columns, what)
        if not isinstance(use_cat_names, bool):
            raise TypeError(f"{what}: use_cat_names must be True or False, got {use_cat_names!r}")
        self.use_cat_names: bool = use_cat_names
        self.handle_unknown: str = _one_of(handle_unknown, allowed, what, "handle_unknown")
        self.handle_missing: str = _one_of(handle_missing, _HANDLE_MISSING, what, "handle_missing")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the encoding kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "use_cat_names": self.use_cat_names,
            "handle_unknown": self.handle_unknown,
            "handle_missing": self.handle_missing,
        }

    @property
    def categories_(self) -> dict[str, list[str]]:
        """Fitted categories per column, sorted.

        Returns:
            Mapping of column name to its sorted category list.

        """
        return self._state()["categories"]


class OneHotEncoder(_Expanding):
    """Categorical utf8 -> one 0/1 column per fitted category, replacing the source column.

    Columns are named ``<column>_<code>`` with the code the encoder would
    have assigned, or ``<column>_<category>`` with ``use_cat_names=True``; a
    name that would repeat gets ``#`` appended, counted across every encoded
    column and not only within one, as category_encoders counts it. A
    null seen at fit under ``handle_missing="value"`` is a category of its
    own, sorted last, and gets its own column. An unseen category is all
    zeros under ``handle_unknown="value"``, all nulls under
    ``"return_nan"``, an error under ``"error"``, and a 1 in an extra
    ``<column>_-1`` column under ``"indicator"``. A null that was never a
    fitted category is all zeros whatever ``handle_unknown`` says. How many
    columns there are is known only after the fit, so a later step in the
    same pipeline cannot name them, and the generated block is appended after
    the columns that stay rather than substituted in the encoded column's
    place.
    """

    kernel_id: ClassVar[str] = "one_hot_encode"


class RankHotEncoder(_Expanding):
    """Categorical utf8 -> thermometer coding: a 1 in every column up to the category's rank.

    The same layout as OneHotEncoder, but a category at rank ``r`` lights up
    every column through ``r`` rather than only its own, which suits an
    ordered category. ``handle_unknown="indicator"`` is not available here,
    matching category_encoders. Two things also follow category_encoders and
    differ from OneHotEncoder: a null that was never a fitted category takes
    ``handle_unknown``'s answer rather than always being zeros (all nulls
    under ``"return_nan"``, all zeros otherwise, never an error), and
    ``handle_missing="return_nan"`` emits one trailing ``<column>_-2`` column
    — ``<column>_nan`` with ``use_cat_names=True`` — that nothing ever
    lights up, for the slot upstream's ordinal pre-encoder keeps there.
    """

    kernel_id: ClassVar[str] = "rank_hot_encode"


_POSITIONAL_UNKNOWN: frozenset[str] = _HANDLE_UNKNOWN | {"indicator"}


class _Positional(Transformer):
    """Shared shell for the encoders that spell a category's rank out digit by digit."""

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            handle_unknown: What an unseen category becomes: "value" (the
                all-zero code word), "return_nan", "error", or "indicator",
                which gives it a code word of its own.
            handle_missing: What a null becomes: "value" (a level of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If columns is a bare string or holds non-strings.
            ValueError: If an option is not one of the accepted values.

        """
        what: str = type(self).__name__
        self.columns: list[str] | None = None if columns is None else _column_list(columns, what)
        self.handle_unknown: str = _one_of(handle_unknown, _POSITIONAL_UNKNOWN, what, "handle_unknown")
        self.handle_missing: str = _one_of(handle_missing, _HANDLE_MISSING, what, "handle_missing")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the encoding kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "handle_unknown": self.handle_unknown,
            "handle_missing": self.handle_missing,
        }

    @property
    def categories_(self) -> dict[str, list[str]]:
        """Fitted categories per column, sorted.

        Returns:
            Mapping of column name to its sorted category list.

        """
        return self._state()["categories"]


class BaseNEncoder(_Positional):
    """Categorical utf8 -> the base-N spelling of the category's rank, one column per digit.

    The category at 1-based rank ``r`` among the sorted levels takes the
    ``digits``-wide base-``base`` representation of ``r``, most significant
    digit first, in columns ``<column>_0`` through
    ``<column>_{digits - 1}``; the source column is replaced.
    ``digits`` is ``ceil(log(levels + 1, base))``, computed with integer
    arithmetic, so the code word ``0`` stays free for an unknown.

    ``base=1`` is category_encoders' documented special case: a rank becomes
    a single 1 at position ``r`` of ``levels + 1`` columns, which is one-hot
    with a leading column that is always zero. ``base=2`` is
    :class:`BinaryEncoder`, and a base equal to the number of levels is
    ordinal encoding spread over one column.

    How many columns the encoder produces is known only after the fit, so a
    later step in the same pipeline cannot name them.
    """

    kernel_id: ClassVar[str] = "basen_encode"

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        base: int = 2,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            base: The base the rank is written in; 1 is the one-hot special
                case, 2 is binary.
            handle_unknown: What an unseen category becomes: "value" (the
                all-zero code word), "return_nan", "error", or "indicator",
                which gives it a code word of its own.
            handle_missing: What a null becomes: "value" (a level of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If columns is a bare string or base is not an integer.
            ValueError: If base is below 1, or an option is not one of the
                accepted values.

        """
        super().__init__(columns, handle_unknown=handle_unknown, handle_missing=handle_missing)
        self.base: int = _integer(base, "BaseNEncoder: base")
        if self.base < 1:
            raise ValueError(f"BaseNEncoder: base must be 1 or more, got {base!r}")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the basen_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {**super().params(), "base": self.base}


class BinaryEncoder(_Positional):
    """Categorical utf8 -> the binary spelling of the category's rank, one column per bit.

    :class:`BaseNEncoder` with the base fixed at 2, as category_encoders
    fixes it: four levels give three columns and the code words ``001``,
    ``010``, ``011`` and ``100``. There is no ``base`` parameter.
    """

    kernel_id: ClassVar[str] = "binary_encode"


class GrayEncoder(_Positional):
    """Categorical utf8 -> the reflected binary (Gray) spelling of the category's rank.

    The same width as :class:`BinaryEncoder`, but the category at rank ``r``
    takes the binary expansion of ``r ^ (r >> 1)``, so consecutive ranks
    differ in exactly one column — which only means anything for an ordered
    category. Five levels give the code words ``001``, ``011``, ``010``,
    ``110`` and ``111``.

    category_encoders sorts the categories for this encoder alone, so unlike
    every other positional port this one matches upstream on any fit data,
    not just data whose categories first appear in sorted order.
    """

    kernel_id: ClassVar[str] = "gray_encode"


class _Contrast(Transformer):
    """Shared shell for the four contrast coders, which differ only in their matrix."""

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            handle_unknown: What an unseen category becomes: "value" (a row of
                zeros), "return_nan", "error", or "indicator", which makes it
                a real extra level and so adds one more output column (a single
                category under handle_missing="value" still emits none, as
                upstream).
            handle_missing: What a null becomes: "value" (a level of its own,
                sorted last), "return_nan", or "error" (refused at transform
                as well as at fit). The last two still keep a placeholder
                level for the missing value that no value can reach, as
                category_encoders does, so they emit one column more than
                the categories alone would.

        Raises:
            TypeError: If columns is a bare string or holds non-strings.
            ValueError: If an option is not one of the accepted values.

        """
        what: str = type(self).__name__
        self.columns: list[str] | None = None if columns is None else _column_list(columns, what)
        self.handle_unknown: str = _one_of(handle_unknown, _HANDLE_UNKNOWN | {"indicator"}, what, "handle_unknown")
        self.handle_missing: str = _one_of(handle_missing, _HANDLE_MISSING, what, "handle_missing")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the contrast kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "handle_unknown": self.handle_unknown,
            "handle_missing": self.handle_missing,
        }

    @property
    def categories_(self) -> dict[str, list[str]]:
        """Fitted categories per column, sorted.

        Returns:
            Mapping of column name to its sorted category list.

        """
        return self._state()["categories"]


class BackwardDifferenceEncoder(_Contrast):
    """Categorical utf8 -> backward difference contrast coding, in f64 columns.

    A column of n fitted levels becomes n - 1 columns named ``<column>_0``
    through ``<column>_{n-2}``, and the level at 0-based index i emits row i
    of the n x (n - 1) matrix ``M[i][j] = (j + 1 - n) / n`` when ``i <= j``
    and ``(j + 1) / n`` otherwise: column j contrasts level j + 1 against the
    levels before it. There is no intercept column, so a column with a single
    level emits nothing at all — unless ``handle_missing`` is ``"return_nan"``
    or ``"error"``, whose placeholder level gives it a second one to contrast
    against. How many columns there are is known only after the fit, so a
    later step in the same pipeline cannot name them, and the generated block
    is appended after the columns that stay rather than substituted in the
    encoded column's place.
    """

    kernel_id: ClassVar[str] = "backward_difference_encode"


class HelmertEncoder(_Contrast):
    """Categorical utf8 -> Helmert contrast coding, in f64 columns.

    The same layout as BackwardDifferenceEncoder, with the matrix
    ``M[i][j] = -1`` when ``i <= j``, ``i`` when ``i == j + 1``, and 0
    otherwise: column j contrasts level j + 1 against the mean of the levels
    before it. Every entry is a small integer held exactly in an f64.
    """

    kernel_id: ClassVar[str] = "helmert_encode"


class SumEncoder(_Contrast):
    """Categorical utf8 -> sum (deviation) contrast coding, in f64 columns.

    The same layout as BackwardDifferenceEncoder, with the identity on every
    level but the last, whose row is all -1: each column contrasts one level
    against the grand mean and the last level is the reference the others are
    read against. Because our levels sort, that reference is the last category
    in byte order — or the fitted null under ``handle_missing="value"``, which
    sorts after every real category.
    """

    kernel_id: ClassVar[str] = "sum_encode"


class PolynomialEncoder(_Contrast):
    """Categorical utf8 -> orthogonal polynomial contrast coding, in f64 columns.

    The same layout as BackwardDifferenceEncoder: column j is the degree
    j + 1 polynomial over the sorted level positions, with the constant
    column omitted. New fits use Arnoldi iteration on centred, bounded
    scores with two orthogonalization passes at each degree, avoiding large
    powers and stabilizing the high-degree basis. Building a matrix for n
    effective levels takes O(n³) work and O(n²) memory; transformation uses
    that matrix as a lookup table.

    New artifacts store the fitted matrix verbatim. Loading a schema 0.2.0
    artifact reconstructs its original modified Gram-Schmidt basis instead.
    Numerical agreement with ``category_encoders`` is not guaranteed at
    arbitrary cardinality: its patsy/LAPACK QR basis also accumulates
    high-degree error, and the stable basis does not reproduce that error.
    """

    kernel_id: ClassVar[str] = "polynomial_encode"


MAX_COMPONENTS: int = 4096


class HashingEncoder(Transformer):
    """The hashing trick: utf8 columns collapse into one shared block of counters.

    The one encoder that learns nothing. A value's bucket is
    ``int.from_bytes(md5(value), "big") % n_components``, a pure function of
    its bytes, so the encoder never grows a vocabulary and a value it never
    saw is no different from any other. Every encoded column feeds the *same*
    block: the encoded columns are dropped and ``col_0`` through
    ``col_{n_components - 1}`` appended after the columns that stay, all i64,
    so a row with k non-null encoded values sums to k across the block. A null
    contributes nothing to any counter.

    Only utf8 columns can be hashed, and the bytes hashed are the value's own.
    ``Cast`` a number to utf8 first: that spells an integer as decimal digits,
    exactly what ``category_encoders``' ``str(value)`` gives, while a float has
    no single spelling and cannot be cast to utf8 at all.

    The output names are upstream's and are fixed, so two HashingEncoders in
    one pipeline would collide; that is a fit-time error rather than a silent
    overwrite. Upstream's ``max_process``, ``max_sample`` and
    ``process_creation_method`` are not ported — they are multiprocessing
    knobs, and the engine already runs one worker per parquet row group.
    """

    kernel_id: ClassVar[str] = "hash_encode"

    def __init__(self, columns: list[str], *, n_components: int = 8, hash_method: str = "md5") -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to hash; every one of them feeds the same block
                of counters and none of them survives to the output.
            n_components: Number of buckets, and so of output columns, from 1
                to 4096. The collision rate is roughly ``1 / n_components``.
            hash_method: The digest to hash with; only ``"md5"``, upstream's
                default, is implemented.

        Raises:
            TypeError: If columns is a bare string or n_components is not an integer.
            ValueError: If columns is empty, n_components is out of range, or
                hash_method is anything but "md5".

        """
        self.columns: list[str] = _column_list(columns, "HashingEncoder")
        self.n_components: int = _integer(n_components, "HashingEncoder: n_components")
        if not 1 <= self.n_components <= MAX_COMPONENTS:
            raise ValueError(f"HashingEncoder: n_components must be between 1 and {MAX_COMPONENTS}, got {n_components}")
        if hash_method != "md5":
            raise ValueError(f"HashingEncoder: hash_method must be 'md5', got {hash_method!r}")
        self.hash_method: str = hash_method

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the hash_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"columns": self.columns, "n_components": self.n_components, "hash_method": self.hash_method}

    @property
    def output_columns(self) -> list[str]:
        """The block this encoder writes, ``col_0`` through ``col_{n_components - 1}``.

        Known from the parameters alone, before any fit, because the encoder
        holds no state.

        Returns:
            The output column names, in block order.

        """
        return [f"col_{index}" for index in range(self.n_components)]


class _TargetBlend(Transformer):
    """Shared shell for the target-mean family: a categorical column learned from a target.

    The target is named in the parameters rather than passed to ``fit``, so a
    saved pipeline rebuilds from its manifest alone and a serving file that
    carries no label still transforms. It is an ordinary integer or float
    column of the input, and it passes through to the output — add a trailing
    ``Select`` to drop it. A row whose target is null teaches nothing; a NaN
    or infinite target is an error.

    Attributes:
        columns: Columns to encode, or None for every utf8 column at fit.
        target: The target column.
        handle_unknown: What an unseen category becomes.
        handle_missing: What a null becomes; "error" is refused at
            transform as well as at fit.

    """

    def __init__(
        self,
        target: str,
        columns: list[str] | None,
        handle_unknown: str,
        handle_missing: str,
    ) -> None:
        """Validate the parameters every kernel in the family shares.

        Args:
            target: The integer or float column to learn from.
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            handle_unknown: What an unseen category becomes: "value",
                "return_nan", or "error".
            handle_missing: What a null becomes: "value", "return_nan", or
                "error" (refused at transform as well as at fit).

        Raises:
            TypeError: If target is not a column name or columns is a bare string.
            ValueError: If columns is empty, holds the target, or an option is
                not one of the accepted values.

        """
        what: str = type(self).__name__
        if not isinstance(target, str) or not target:
            raise TypeError(f"{what}: target must be a column name, got {target!r}")
        self.columns: list[str] | None = None if columns is None else _column_list(columns, what)
        if self.columns is not None and target in self.columns:
            raise ValueError(f"{what}: column {target!r} is also the target; a target encoder cannot encode its target")
        if handle_unknown not in _HANDLE_UNKNOWN:
            raise ValueError(f"{what}: handle_unknown must be one of {sorted(_HANDLE_UNKNOWN)}, got {handle_unknown!r}")
        if handle_missing not in _HANDLE_MISSING:
            raise ValueError(f"{what}: handle_missing must be one of {sorted(_HANDLE_MISSING)}, got {handle_missing!r}")
        self.target: str = target
        self.handle_unknown: str = handle_unknown
        self.handle_missing: str = handle_missing

    def _shared_params(self) -> dict[str, Any]:
        """Parameters every kernel in the family takes.

        Returns:
            The declarative parameter mapping shared by the family.

        """
        return {
            "columns": self.columns,
            "target": self.target,
            "handle_unknown": self.handle_unknown,
            "handle_missing": self.handle_missing,
        }

    @property
    def prior_(self) -> float:
        """The fit-wide target mean: the sum of the target over its non-null count.

        Returns:
            The prior.

        """
        return self._state()["prior"]

    @property
    def values_(self) -> dict[str, dict[str, float]]:
        """Fitted category -> encoded value tables, materialized from the C++ core.

        Returns:
            Mapping of column name to its category -> value table.

        """
        return self._state()["values"]

    @property
    def null_values_(self) -> dict[str, float | None]:
        """The value of each column's null category, or None where it has none.

        Returns:
            Mapping of column name to the null category's value.

        """
        return self._state()["null_values"]


def _positive(value: Any, what: str) -> float:
    """Validate a strictly positive smoothing-style parameter.

    Args:
        value: The value to check.
        what: What the value is, for the error message.

    Returns:
        The value as a float.

    Raises:
        TypeError: If the value is a bool or not a number.
        ValueError: If the value is not positive or not finite.

    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{what} must be a number, got {value!r}")
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{what} must be positive, got {value!r}")
    return float(value)


class TargetEncoder(_TargetBlend):
    """Categorical utf8 -> a blend of the category's target mean and the fit-wide prior.

    ``TargetEncoder(target="clicked", columns=["city"])`` learns, for each
    category, how many rows carried it (``n``) and what their target summed to
    (``s``), and encodes it as ``prior * (1 - w) + (s / n) * w``, where
    ``prior`` is the target mean over every fit row and
    ``w = 1 / (1 + exp(-(n - min_samples_leaf) / smoothing))`` is an S-curve
    that trusts a category the more rows it has. The output is f64. A null is
    a category of its own under ``handle_missing="value"`` (a null unseen at
    fit takes the prior), a null under ``"return_nan"``, and an error under
    ``"error"``. An unseen category takes the prior under
    ``handle_unknown="value"``, a null under ``"return_nan"``, and is an error
    under ``"error"``. The ``hierarchy`` parameter of ``category_encoders`` is
    not supported: it needs extra columns describing a tree of categories.
    """

    kernel_id: ClassVar[str] = "target_encode"

    def __init__(
        self,
        target: str,
        columns: list[str] | None = None,
        *,
        min_samples_leaf: int = 20,
        smoothing: float = 10.0,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            target: The integer or float column to learn from; it passes
                through to the output.
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            min_samples_leaf: The category size at which the S-curve reaches
                0.5, so a smaller category leans on the prior.
            smoothing: How flat that S-curve is; must be positive.
            handle_unknown: What an unseen category becomes: "value" (the
                prior), "return_nan", or "error".
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If an argument has the wrong type.
            ValueError: If an option is not one of the accepted values.

        """
        super().__init__(target, columns, handle_unknown, handle_missing)
        self.min_samples_leaf: int = _integer(min_samples_leaf, "TargetEncoder: min_samples_leaf")
        self.smoothing: float = _positive(smoothing, "TargetEncoder: smoothing")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the target_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return self._shared_params() | {"min_samples_leaf": self.min_samples_leaf, "smoothing": self.smoothing}


class MEstimateEncoder(_TargetBlend):
    """Categorical utf8 -> the m-probability estimate of its target mean.

    ``MEstimateEncoder(target="clicked", columns=["city"])`` is the
    one-parameter cousin of TargetEncoder: a category carrying ``n`` rows that
    sum to ``s`` encodes as ``(s + prior * m) / (n + m)``, which is the
    category mean pulled toward the fit-wide prior by ``m`` imagined prior
    rows. A column with as many categories as fit rows is id-like and teaches
    nothing, so the whole column becomes the prior. The output is f64, and
    nulls and unseen categories follow ``handle_missing`` and
    ``handle_unknown`` as they do for TargetEncoder. The ``randomized`` and
    ``sigma`` parameters of ``category_encoders`` are not supported: they
    multiply the training-time output by Gaussian noise and are off by
    default.
    """

    kernel_id: ClassVar[str] = "m_estimate_encode"

    def __init__(
        self,
        target: str,
        columns: list[str] | None = None,
        *,
        m: float = 1.0,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            target: The integer or float column to learn from; it passes
                through to the output.
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            m: How many prior rows a category is shrunk toward the prior by;
                must not be negative.
            handle_unknown: What an unseen category becomes: "value" (the
                prior), "return_nan", or "error".
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If an argument has the wrong type.
            ValueError: If an option is not one of the accepted values.

        """
        super().__init__(target, columns, handle_unknown, handle_missing)
        if isinstance(m, bool) or not isinstance(m, (int, float)):
            raise TypeError(f"MEstimateEncoder: m must be a number, got {m!r}")
        if not math.isfinite(m) or m < 0:
            raise ValueError(f"MEstimateEncoder: m must not be negative, got {m!r}")
        self.m: float = float(m)

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the m_estimate_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return self._shared_params() | {"m": self.m}


class WOEEncoder(_TargetBlend):
    """Categorical utf8 -> the weight of evidence of its binary target.

    ``WOEEncoder(target="clicked", columns=["city"])`` encodes a category
    carrying ``n`` rows that sum to ``s`` as
    ``ln(((s + r) / (S + 2r)) / (((n - s) + r) / ((N - S) + 2r)))``, the log
    odds of the category against the fit-wide odds, where ``S`` and ``N`` are
    the target's sum and row count and ``r`` is ``regularization`` (which
    keeps the ratio away from zero). The target must be binary: exactly two
    distinct values, one of them 0 or less and the other 1 or more, or the fit
    is an error. A category seen exactly once encodes as 0, and so does an
    unseen category — the scale is centred on 0, not on the prior. The output
    is f64. The ``randomized`` and ``sigma`` parameters of
    ``category_encoders`` are not supported: they multiply the training-time
    output by Gaussian noise and are off by default.
    """

    kernel_id: ClassVar[str] = "woe_encode"

    def __init__(
        self,
        target: str,
        columns: list[str] | None = None,
        *,
        regularization: float = 1.0,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            target: The binary integer or float column to learn from; it
                passes through to the output.
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            regularization: Added to both halves of the odds ratio so neither
                can be zero; must be positive.
            handle_unknown: What an unseen category becomes: "value" (0),
                "return_nan", or "error".
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If an argument has the wrong type.
            ValueError: If an option is not one of the accepted values.

        """
        super().__init__(target, columns, handle_unknown, handle_missing)
        self.regularization: float = _positive(regularization, "WOEEncoder: regularization")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the woe_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return self._shared_params() | {"regularization": self.regularization}


class _ShrinkageEncoder(Transformer):
    """Shared shell for the target encoders that shrink a category mean toward the prior.

    The target column is named in the parameters, not handed to ``fit``: a
    fitted artifact rebuilds from the manifest alone, and ``Pipeline.fit``'s
    ``y`` stays ignored. While unfitted the step reads the target as well as
    its columns; once fitted it reads only its columns, so a serving file
    without the label still transforms. The target itself passes through to
    the output — add a trailing ``Select`` to drop it.
    """

    def __init__(
        self,
        columns: list[str] | None,
        target: str,
        handle_unknown: str,
        handle_missing: str,
    ) -> None:
        """Validate the arguments every shrinkage encoder shares.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            target: The integer or float column to take the statistics from.
            handle_unknown: What an unseen category becomes: "value" (the
                prior), "return_nan", or "error".
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If columns is a bare string or target is not a column name.
            ValueError: If an option is not one of the accepted values.

        """
        what: str = type(self).__name__
        self.columns: list[str] | None = None if columns is None else _column_list(columns, what)
        if not isinstance(target, str) or not target:
            raise TypeError(f"{what}: target must be a column name, got {target!r}")
        if handle_unknown not in _HANDLE_UNKNOWN:
            raise ValueError(f"{what}: handle_unknown must be one of {sorted(_HANDLE_UNKNOWN)}, got {handle_unknown!r}")
        if handle_missing not in _HANDLE_MISSING:
            raise ValueError(f"{what}: handle_missing must be one of {sorted(_HANDLE_MISSING)}, got {handle_missing!r}")
        self.target: str = target
        self.handle_unknown: str = handle_unknown
        self.handle_missing: str = handle_missing

    def params(self) -> dict[str, Any]:
        """Kernel parameters shared by the shrinkage encoders.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "target": self.target,
            "handle_unknown": self.handle_unknown,
            "handle_missing": self.handle_missing,
        }

    @property
    def prior_(self) -> float:
        """The target's mean over the fitted rows, the value every category is shrunk toward.

        Returns:
            The prior.

        """
        return self._state()["prior"]

    @property
    def values_(self) -> dict[str, dict[str, float]]:
        """Fitted category -> encoded value tables, materialized from the C++ core.

        Returns:
            Mapping of column name to its category -> value table.

        """
        return self._state()["values"]


JAMES_STEIN_MODELS: frozenset[str] = frozenset({"independent", "pooled", "beta"})


class JamesSteinEncoder(_ShrinkageEncoder):
    """Categorical utf8 -> the target mean of its category, shrunk toward the global mean.

    The weight is closed-form rather than cross-validated, and ``model``
    chooses how it is computed. With ``m_c`` the category's target mean,
    ``n_c`` its row count, ``K`` the number of categories, ``N`` the fitted
    rows, and ``prior`` the target's global mean:

    * ``independent`` (the default) weighs each category on its own variance:
      ``B_c = i_var_c / (var(y) + i_var_c) * (K - 3) / (K - 1)``, where
      ``i_var_c`` is the within-category sample variance (0 for a category of
      one row), the weight is ``clip(1 - B_c, 0, 1)`` and the value is
      ``w_c * m_c + (1 - w_c) * prior``.
    * ``pooled`` assumes one variance for every category:
      ``variance = var(y) / (N / K)``, ``SSE = sum (m_c - prior)^2``,
      ``B = clip((K - 3) * variance / SSE, 0, 1)``, and the value is
      ``prior + (1 - B) * (m_c - prior)``.
    * ``beta`` weighs a category by its size alone: ``w_c = n_c / (n_c + N)``.

    A column with as many categories as rows identifies the row, so every
    category collapses to the prior, as upstream does. ``model="binary"`` is
    refused: upstream reads its estimate out of a module global that its
    optimizer happens to leave behind, so the result is not reproducible from
    the published formula. A constant target leaves the ``independent`` weight
    at 0/0, which upstream answers with NaN and we answer with the category
    mean, which is the prior. Upstream's ``randomized``/``sigma`` add Gaussian
    noise at training time only, so they are not parameters here.
    """

    kernel_id: ClassVar[str] = "james_stein_encode"

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        target: str,
        model: str = "independent",
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            target: The integer or float column to take the statistics from.
            model: One of ``independent``, ``pooled``, ``beta``.
            handle_unknown: What an unseen category becomes: "value" (the
                prior), "return_nan", or "error".
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If columns is a bare string or target is not a column name.
            ValueError: If model or an option is not one of the accepted values.

        """
        super().__init__(columns, target, handle_unknown, handle_missing)
        if model == "binary":
            raise ValueError(
                "JamesSteinEncoder: model='binary' reads its estimate from a module global that upstream's "
                "optimizer leaves behind, so it is not reproducible from the formula and not portable; "
                f"choose one of {sorted(JAMES_STEIN_MODELS)}"
            )
        if model not in JAMES_STEIN_MODELS:
            raise ValueError(f"JamesSteinEncoder: model must be one of {sorted(JAMES_STEIN_MODELS)}, got {model!r}")
        self.model: str = model

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the james_stein_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {**super().params(), "model": self.model}


class LeaveOneOutEncoder(_ShrinkageEncoder):
    """Categorical utf8 -> the target mean of its category, with a singleton collapsing to the prior.

    The value is ``sum_c / n_c`` when the category has more than one row and
    the target's global mean otherwise, so a category of one row cannot leak
    that row's own target. This is upstream's **inference** form (its
    ``transform`` called without a target). Upstream's ``fit_transform``
    instead leaves each training row's own target out of its own value, which
    is a function of the row rather than of the fitted state; our transform is
    a pure function of frozen state, so those training-time values are not
    reproduced. Upstream's ``sigma``/``random_state`` add Gaussian noise at
    training time only, so they are not parameters here.
    """

    kernel_id: ClassVar[str] = "leave_one_out_encode"

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        target: str,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            target: The integer or float column to take the statistics from.
            handle_unknown: What an unseen category becomes: "value" (the
                prior), "return_nan", or "error".
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If columns is a bare string or target is not a column name.
            ValueError: If an option is not one of the accepted values.

        """
        super().__init__(columns, target, handle_unknown, handle_missing)


class CatBoostEncoder(_ShrinkageEncoder):
    """Categorical utf8 -> the target mean of its category, smoothed toward the prior.

    The value is ``(sum_c + prior * a) / (n_c + a)`` when the category has
    more than one row — ``a`` extra observations worth of prior, 1 by default
    — and the raw prior otherwise, so a singleton is replaced rather than
    smoothed. This is upstream's **inference** form (its ``transform`` called
    without a target). Upstream's ``fit_transform`` instead walks the training
    rows in order and gives each row the running statistic of the rows before
    it, which depends on row order; our fits do not, so those training-time
    values are not reproduced. Upstream's ``sigma``/``random_state`` add
    Gaussian noise at training time only, so there is nothing to reproduce at
    inference and they are not parameters here.
    """

    kernel_id: ClassVar[str] = "cat_boost_encode"

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        target: str,
        a: float = 1.0,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            columns: Columns to encode; None encodes every utf8 column found
                at fit time.
            target: The integer or float column to take the statistics from.
            a: Additive smoothing — how many prior-valued observations every
                category is credited with.
            handle_unknown: What an unseen category becomes: "value" (the
                prior), "return_nan", or "error".
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If columns is a bare string, target is not a column
                name, or a is not a number.
            ValueError: If a is negative or an option is not one of the
                accepted values.

        """
        super().__init__(columns, target, handle_unknown, handle_missing)
        if isinstance(a, bool) or not isinstance(a, (int, float)):
            raise TypeError(f"CatBoostEncoder: a must be a number, got {a!r}")
        if not a >= 0 or a == float("inf"):
            raise ValueError(f"CatBoostEncoder: a must be a finite number >= 0, got {a!r}")
        self.a: float = float(a)

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the cat_boost_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {**super().params(), "a": self.a}


def _target(target: object, what: str) -> str:
    """Validate a supervised encoder's target column name.

    Args:
        target: The value passed for a ``target`` argument.
        what: The transformer name, for the error message.

    Returns:
        The target column name.

    Raises:
        TypeError: If target is not a non-empty string.

    """
    if not isinstance(target, str) or not target:
        raise TypeError(f"{what}: target must be a column name, got {target!r}")
    return target


def _quantile(quantile: object, what: str, key: str) -> float:
    """Validate one quantile.

    Args:
        quantile: The value passed for a quantile.
        what: The transformer name, for the error message.
        key: The argument name, for the error message.

    Returns:
        The quantile as a float.

    Raises:
        TypeError: If the quantile is not a number.
        ValueError: If the quantile is outside [0, 1].

    """
    if isinstance(quantile, bool) or not isinstance(quantile, (int, float)):
        raise TypeError(f"{what}: {key} must be a number between 0 and 1, got {quantile!r}")
    if not 0.0 <= quantile <= 1.0:
        raise ValueError(f"{what}: {key} must be a number between 0 and 1, got {quantile!r}")
    return float(quantile)


def _smoothing(m: object, what: str) -> float:
    """Validate an m-probability smoothing weight.

    Args:
        m: The value passed for ``m``.
        what: The transformer name, for the error message.

    Returns:
        The weight as a float.

    Raises:
        TypeError: If m is not a number.
        ValueError: If m is negative or not finite.

    """
    if isinstance(m, bool) or not isinstance(m, (int, float)):
        raise TypeError(f"{what}: m must be a number >= 0, got {m!r}")
    if not math.isfinite(m) or m < 0:
        raise ValueError(f"{what}: m must be a number >= 0, got {m!r}")
    return float(m)


def _handling(option: object, accepted: frozenset[str], what: str, key: str) -> str:
    """Validate one of the unknown/missing strategies the supervised encoders share.

    Args:
        option: The value passed for the strategy.
        accepted: The strategies this argument accepts.
        what: The transformer name, for the error message.
        key: The argument name, for the error message.

    Returns:
        The strategy.

    Raises:
        ValueError: If the strategy is not one of the accepted values.

    """
    if option not in accepted:
        raise ValueError(f"{what}: {key} must be one of {sorted(accepted)}, got {option!r}")
    return str(option)


class QuantileEncoder(Transformer):
    """Categorical utf8 -> a quantile of the target, shrunk toward the global quantile.

    ``QuantileEncoder(target="price", columns=["city"], quantile=0.5)`` fits
    the quantile of ``price`` over every row (the prior) and over the rows of
    each category, then encodes a category holding ``n`` target values whose
    quantile is ``q`` as ``(n * q + prior * m) / (n + m)``: ``m=0`` is the raw
    quantile and a large ``m`` is the prior. The quantile is numpy's
    ``"linear"`` method, so it interpolates between the two values around
    ``quantile * (n - 1)``. The target is named here rather than passed to
    ``fit``, so a loaded artifact rebuilds the step exactly; it must be an
    integer or float column, it cannot be one of ``columns``, and it passes
    through to the output (add a trailing ``Select`` to drop it). A row whose
    target is null contributes to nothing. A null category is a category of
    its own under ``handle_missing="value"``, a null under ``"return_nan"``,
    and an error under ``"error"`` (at transform as well as at fit); an
    unseen category — and a null
    the fit never saw — yields the prior under ``handle_unknown="value"``, a
    null under ``"return_nan"``, and an error under ``"error"``. The encoded
    column becomes f64 in place. An exact quantile needs every target value,
    so this is the buffered tier: values are retained per encoded column and
    for the global prior in automatically spillable storage. Exact ranks use
    external sorting when spilled; disk usage still grows with the sample.
    """

    kernel_id: ClassVar[str] = "quantile_encode"

    def __init__(
        self,
        target: str,
        columns: list[str] | None = None,
        *,
        quantile: float = 0.5,
        m: float = 1.0,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            target: The integer or float column whose quantile is encoded.
            columns: Columns to encode; None encodes every utf8 column found
                at fit time, except the target.
            quantile: The quantile to take, between 0 and 1; 0.5 is the median.
            m: The m-probability smoothing weight; 0 disables smoothing.
            handle_unknown: What an unseen category becomes: "value" (the
                prior), "return_nan", or "error".
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If target, columns, quantile, or m has the wrong type.
            ValueError: If quantile is outside [0, 1], m is negative, or a
                handling option is not one of the accepted values.

        """
        self.target: str = _target(target, "QuantileEncoder")
        self.columns: list[str] | None = None if columns is None else _column_list(columns, "QuantileEncoder")
        self.quantile: float = _quantile(quantile, "QuantileEncoder", "quantile")
        self.m: float = _smoothing(m, "QuantileEncoder")
        self.handle_unknown: str = _handling(handle_unknown, _HANDLE_UNKNOWN, "QuantileEncoder", "handle_unknown")
        self.handle_missing: str = _handling(handle_missing, _HANDLE_MISSING, "QuantileEncoder", "handle_missing")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the quantile_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "target": self.target,
            "quantile": self.quantile,
            "m": self.m,
            "handle_unknown": self.handle_unknown,
            "handle_missing": self.handle_missing,
        }

    @property
    def prior_(self) -> float:
        """The fitted quantile of the target over every fit row.

        Returns:
            The prior.

        """
        return self._state()["priors"][0]

    @property
    def categories_(self) -> dict[str, list[str]]:
        """Fitted categories per encoded column, sorted.

        Returns:
            Mapping of column name to its categories.

        """
        return self._state()["categories"]

    @property
    def encodings_(self) -> dict[str, list[float]]:
        """Fitted values per encoded column, aligned with ``categories_``.

        Returns:
            Mapping of column name to one encoded value per category.

        """
        return self._state()["encodings"]


class SummaryEncoder(Transformer):
    """QuantileEncoder at several quantiles at once, one output column each.

    ``SummaryEncoder(target="price", columns=["city"], quantiles=(0.25, 0.75))``
    fits one QuantileEncoder per quantile over the same data and replaces
    each encoded column, in its own position, with one f64 column per
    quantile named ``<column>_<round(quantile * 100)>``, in the order the
    quantiles were given. Everything else — the smoothing, the target rules,
    the null and unknown handling, and the O(rows) sample storage with automatic spilling — is
    QuantileEncoder's. Two quantiles that round to the same percentile would
    name the same column and are rejected.
    """

    kernel_id: ClassVar[str] = "summary_encode"

    def __init__(
        self,
        target: str,
        columns: list[str] | None = None,
        *,
        quantiles: Sequence[float] = (0.25, 0.75),
        m: float = 1.0,
        handle_unknown: str = "value",
        handle_missing: str = "value",
    ) -> None:
        """Initialize the encoder.

        Args:
            target: The integer or float column whose quantiles are encoded.
            columns: Columns to encode; None encodes every utf8 column found
                at fit time, except the target.
            quantiles: The quantiles to take, each between 0 and 1.
            m: The m-probability smoothing weight; 0 disables smoothing.
            handle_unknown: What an unseen category becomes: "value" (the
                prior), "return_nan", or "error".
            handle_missing: What a null becomes: "value" (a category of its
                own), "return_nan", or "error" (refused at transform as well
                as at fit).

        Raises:
            TypeError: If target, columns, quantiles, or m has the wrong type.
            ValueError: If quantiles is empty, holds a value outside [0, 1] or
                two that round to the same percentile, m is negative, or a
                handling option is not one of the accepted values.

        """
        self.target: str = _target(target, "SummaryEncoder")
        self.columns: list[str] | None = None if columns is None else _column_list(columns, "SummaryEncoder")
        if isinstance(quantiles, str) or not isinstance(quantiles, (list, tuple)) or not quantiles:
            raise TypeError(f"SummaryEncoder: quantiles must be a non-empty list of numbers, got {quantiles!r}")
        self.quantiles: list[float] = [_quantile(value, "SummaryEncoder", "quantiles") for value in quantiles]
        percentiles: list[int] = [round(value * 100) for value in self.quantiles]
        if len(set(percentiles)) != len(percentiles):
            raise ValueError(f"SummaryEncoder: two quantiles round to the same percentile, got {self.quantiles!r}")
        self.m: float = _smoothing(m, "SummaryEncoder")
        self.handle_unknown: str = _handling(handle_unknown, _HANDLE_UNKNOWN, "SummaryEncoder", "handle_unknown")
        self.handle_missing: str = _handling(handle_missing, _HANDLE_MISSING, "SummaryEncoder", "handle_missing")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the summary_encode kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "target": self.target,
            "quantiles": self.quantiles,
            "m": self.m,
            "handle_unknown": self.handle_unknown,
            "handle_missing": self.handle_missing,
        }

    @property
    def priors_(self) -> list[float]:
        """The fitted quantiles of the target over every fit row, in ``quantiles`` order.

        Returns:
            One prior per quantile.

        """
        return self._state()["priors"]

    @property
    def categories_(self) -> dict[str, list[str]]:
        """Fitted categories per encoded column, sorted.

        Returns:
            Mapping of column name to its categories.

        """
        return self._state()["categories"]

    @property
    def encodings_(self) -> dict[str, list[float]]:
        """Fitted values per generated column, aligned with its source column's ``categories_``.

        Returns:
            Mapping of ``<column>_<percentile>`` to one encoded value per category.

        """
        return self._state()["encodings"]


def _flag(value: object, what: str, key: str) -> bool:
    """Validate a boolean option.

    Args:
        value: The value passed for the option.
        what: The transformer name, for the error message.
        key: The option name, for the error message.

    Returns:
        The value.

    Raises:
        TypeError: If the value is not a bool.

    """
    if not isinstance(value, bool):
        raise TypeError(f"{what}: {key} must be True or False, got {value!r}")
    return value


def _finite(value: object, what: str, key: str) -> float:
    """Validate a finite number.

    Args:
        value: The value passed for the option.
        what: The transformer name, for the error message.
        key: The option name, for the error message.

    Returns:
        The value as a float.

    Raises:
        TypeError: If the value is not a number.
        ValueError: If the value is not finite.

    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{what}: {key} must be a number, got {value!r}")
    if not math.isfinite(value):
        raise ValueError(f"{what}: {key} must be a finite number, got {value!r}")
    return float(value)


class _Scaler(Transformer):
    """Shared shell for the three fitted scalers: a numeric column list and its row count.

    ``columns=None`` scales every integer or float column that reaches the
    step, chosen once at fit and frozen into the artifact. A null teaches
    nothing and comes out a null, which is what scikit-learn's NaN does; a
    NaN or infinity in the data itself is an error, because a missing number
    has one spelling here. Every scaled column becomes f64 whatever width it
    arrived as.
    """

    def __init__(self, columns: list[str] | None = None) -> None:
        """Initialize the scaler.

        Args:
            columns: Columns to scale; None scales every integer or float
                column found at fit time.

        Raises:
            TypeError: If columns is a bare string or holds non-strings.
            ValueError: If columns is empty.

        """
        self.columns: list[str] | None = None if columns is None else _column_list(columns, type(self).__name__)

    @property
    def scale_(self) -> dict[str, float]:
        """The divisor (or multiplier) fitted for each column.

        Returns:
            Mapping of column name to its fitted scale.

        """
        return self._state()["scales"]


class StandardScaler(_Scaler):
    """Numeric columns -> ``(x - mean) / sqrt(var)``, the scikit-learn scaler.

    ``StandardScaler(columns=["price"])`` fits the mean and the **population**
    variance (``ddof=0``) of ``price`` over its non-null values, then encodes
    ``(x - mean_) / scale_`` — subtracting and then dividing, in that order.
    ``scale_`` is ``sqrt(var_)`` except for a column whose variance is
    indistinguishable from zero, which scales by 1 instead, so a constant
    column comes out 0 rather than NaN; that is scikit-learn's own bound,
    ``var <= n * eps * var + (n * mean * eps) ** 2``, taken on the variance
    before the square root. ``with_mean=False`` leaves out the centring and
    ``with_std=False`` the division; both statistics are recorded either way,
    because they cost one pass whichever flags are set.

    The sums are exact partials and the variance is the correctly rounded
    exact ``sum((x - mean) ** 2)``, so the fitted table never depends on how
    the rows were split across workers. scikit-learn accumulates both
    incrementally instead, so the two agree by accident rather than by
    construction: ``mean_`` can differ from upstream's by up to one ulp *of
    the mean*, and with ``with_std=False`` nothing divides that away, so it
    reaches the output undivided and grows with the column's magnitude — on
    ``[1e16, 1.0000000000000004e16, 1e16, 1e16, 1.0000000000000004e16]`` ours
    centres on ``1.0000000000000002e16`` (the correctly rounded mean) against
    upstream's ``1e16``, and every output value differs by 2.0. Ours is the
    more accurate answer. Every parity case lands on the same bits.
    """

    kernel_id: ClassVar[str] = "standard_scale"

    def __init__(self, columns: list[str] | None = None, *, with_mean: bool = True, with_std: bool = True) -> None:
        """Initialize the scaler.

        Args:
            columns: Columns to scale; None scales every integer or float
                column found at fit time.
            with_mean: Subtract the fitted mean.
            with_std: Divide by the fitted scale.

        Raises:
            TypeError: If columns is a bare string, or a flag is not a bool.
            ValueError: If columns is empty.

        """
        super().__init__(columns)
        self.with_mean: bool = _flag(with_mean, "StandardScaler", "with_mean")
        self.with_std: bool = _flag(with_std, "StandardScaler", "with_std")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the standard_scale kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"columns": self.columns, "with_mean": self.with_mean, "with_std": self.with_std}

    @property
    def mean_(self) -> dict[str, float]:
        """The fitted mean of each column's non-null values.

        Returns:
            Mapping of column name to its mean.

        """
        return self._state()["means"]

    @property
    def var_(self) -> dict[str, float]:
        """The fitted population variance (``ddof=0``) of each column's non-null values.

        Returns:
            Mapping of column name to its variance.

        """
        return self._state()["variances"]

    @property
    def n_samples_seen_(self) -> dict[str, int]:
        """How many non-null values each column contributed, as scikit-learn counts them.

        Returns:
            Mapping of column name to its non-null count.

        """
        return self._state()["counts"]


class MinMaxScaler(_Scaler):
    """Numeric columns -> ``x * scale_ + min_``, mapping the fitted range onto ``feature_range``.

    ``MinMaxScaler(columns=["price"], feature_range=(0, 1))`` fits
    ``data_min_`` and ``data_max_``, then
    ``scale_ = (high - low) / (data_max_ - data_min_)`` and
    ``min_ = low - data_min_ * scale_``, so the smallest fitted value lands on
    ``low`` and the largest on ``high``. A column whose range is
    indistinguishable from zero divides by 1 instead, so a constant column
    comes out at ``low`` rather than NaN. ``clip=True`` clamps the result back
    into ``feature_range``, which only a value outside the fitted range can
    leave. The minimum and maximum are exact under any split, so the fitted
    table is bit-identical however the rows were divided across workers.
    """

    kernel_id: ClassVar[str] = "min_max_scale"

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        feature_range: Sequence[float] = (0.0, 1.0),
        clip: bool = False,
    ) -> None:
        """Initialize the scaler.

        Args:
            columns: Columns to scale; None scales every integer or float
                column found at fit time.
            feature_range: The (low, high) range the fitted range maps onto.
            clip: Clamp transformed values into feature_range.

        Raises:
            TypeError: If columns is a bare string, feature_range is not a
                pair of numbers, or clip is not a bool.
            ValueError: If columns is empty, or feature_range is not two
                finite numbers with the first below the second.

        """
        super().__init__(columns)
        if isinstance(feature_range, str) or not isinstance(feature_range, (list, tuple)) or len(feature_range) != 2:
            raise TypeError(f"MinMaxScaler: feature_range must be a (low, high) pair, got {feature_range!r}")
        low: float = _finite(feature_range[0], "MinMaxScaler", "feature_range")
        high: float = _finite(feature_range[1], "MinMaxScaler", "feature_range")
        if low >= high:
            raise ValueError(f"MinMaxScaler: feature_range must be (low, high) with low < high, got {feature_range!r}")
        self.feature_range: tuple[float, float] = (low, high)
        self.clip: bool = _flag(clip, "MinMaxScaler", "clip")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the min_max_scale kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"columns": self.columns, "feature_range": list(self.feature_range), "clip": self.clip}

    @property
    def data_min_(self) -> dict[str, float]:
        """The smallest non-null value fitted per column.

        Returns:
            Mapping of column name to its minimum.

        """
        return self._state()["data_min"]

    @property
    def data_max_(self) -> dict[str, float]:
        """The largest non-null value fitted per column.

        Returns:
            Mapping of column name to its maximum.

        """
        return self._state()["data_max"]

    @property
    def data_range_(self) -> dict[str, float]:
        """The fitted spread per column, ``data_max_ - data_min_``.

        Returns:
            Mapping of column name to its range.

        """
        highs: dict[str, float] = self.data_max_
        return {column: highs[column] - low for column, low in self.data_min_.items()}

    @property
    def min_(self) -> dict[str, float]:
        """The offset added after scaling, ``low - data_min_ * scale_``.

        Returns:
            Mapping of column name to its offset.

        """
        return self._state()["mins"]

    @property
    def n_samples_seen_(self) -> int:
        """How many rows the fit read, nulls included, as scikit-learn counts them.

        Returns:
            The fitted row count.

        """
        return self._state()["rows"]


class MaxAbsScaler(_Scaler):
    """Numeric columns -> ``x / max_abs_``, the scaler that leaves a zero a zero.

    ``MaxAbsScaler(columns=["price"])`` fits the largest absolute non-null
    value of ``price`` and divides by it, so the fitted data lands in
    ``[-1, 1]`` without shifting anything — the scaler to reach for when zero
    means "absent". A column whose largest absolute value is
    indistinguishable from zero divides by 1 instead, so an all-zero column
    comes out zeros. ``clip=True`` clamps the result to ``[-1, 1]``, which
    only a value larger than anything seen at fit can leave. The maximum is
    exact under any split, so the fitted table is bit-identical however the
    rows were divided across workers.
    """

    kernel_id: ClassVar[str] = "max_abs_scale"

    def __init__(self, columns: list[str] | None = None, *, clip: bool = False) -> None:
        """Initialize the scaler.

        Args:
            columns: Columns to scale; None scales every integer or float
                column found at fit time.
            clip: Clamp transformed values to [-1, 1].

        Raises:
            TypeError: If columns is a bare string or clip is not a bool.
            ValueError: If columns is empty.

        """
        super().__init__(columns)
        self.clip: bool = _flag(clip, "MaxAbsScaler", "clip")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the max_abs_scale kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"columns": self.columns, "clip": self.clip}

    @property
    def max_abs_(self) -> dict[str, float]:
        """The largest absolute non-null value fitted per column.

        Returns:
            Mapping of column name to its maximum magnitude.

        """
        return self._state()["max_abs"]

    @property
    def n_samples_seen_(self) -> int:
        """How many rows the fit read, nulls included, as scikit-learn counts them.

        Returns:
            The fitted row count.

        """
        return self._state()["rows"]


class Binarizer(Transformer):
    """Numeric columns -> 0 or 1 by a threshold. Stateless.

    ``Binarizer(columns=["clicks"], threshold=0.0)`` writes 1 where the value
    is **strictly** above the threshold and 0 everywhere else, so a value
    sitting exactly on the threshold is a 0. A null is an error rather than a
    0 or a 1: scikit-learn's ``Binarizer`` refuses a NaN outright instead of
    guessing, and so do we, at transform in batch and record mode alike.
    scikit-learn keeps the input dtype; our output type is declared, so the
    column becomes i64 whatever came in.

    ``columns`` is required because nothing is learned: an artifact that did
    not name them would binarize a different set of columns for every file it
    was handed.
    """

    kernel_id: ClassVar[str] = "binarize"

    def __init__(self, columns: list[str], *, threshold: float = 0.0) -> None:
        """Initialize the binarizer.

        Args:
            columns: Columns to binarize; every one of them becomes i64.
            threshold: Values strictly above this become 1, the rest 0.

        Raises:
            TypeError: If columns is a bare string or threshold is not a number.
            ValueError: If columns is empty or threshold is not finite.

        """
        self.columns: list[str] = _column_list(columns, "Binarizer")
        self.threshold: float = _finite(threshold, "Binarizer", "threshold")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the binarize kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"columns": self.columns, "threshold": self.threshold}


NORMS: frozenset[str] = frozenset({"l1", "l2", "max"})


class Normalizer(Transformer):
    """Each row divided by its own norm across the listed columns. Stateless.

    ``Normalizer(columns=["x", "y", "z"], norm="l2")`` divides every row by
    ``sqrt(x**2 + y**2 + z**2)``; ``norm="l1"`` divides by ``|x| + |y| + |z|``
    and ``norm="max"`` by the largest of the three magnitudes. A row whose
    norm is indistinguishable from zero is left alone rather than divided, so
    an all-zero row stays all zeros.

    This is the one kernel whose answer for a column depends on the *other*
    columns of the same row, which is why ``columns`` is a required, ordered
    parameter with no ``None`` spelling: the artifact has to name the whole
    vector, or the same saved model would normalize by a different set of
    columns for every file it was handed. A file missing one of them is an
    error rather than a quietly different answer. A null is an error too, as
    scikit-learn's NaN is: a norm over a missing number has no value. The l1
    and l2 sums are exact partials, so the norm does not depend on the order
    the columns were listed in, and every listed column becomes f64.
    """

    kernel_id: ClassVar[str] = "normalize"

    def __init__(self, columns: list[str], *, norm: str = "l2") -> None:
        """Initialize the normalizer.

        Args:
            columns: The ordered vector each row is normalized over; every
                one of them becomes f64.
            norm: The norm to divide by: "l1", "l2", or "max".

        Raises:
            TypeError: If columns is a bare string or holds non-strings.
            ValueError: If columns is empty or norm is not one of the
                accepted values.

        """
        self.columns: list[str] = _column_list(columns, "Normalizer")
        self.norm: str = _one_of(norm, NORMS, "Normalizer", "norm")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the normalize kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"columns": self.columns, "norm": self.norm}


_OUTPUT_DISTRIBUTIONS: frozenset[str] = frozenset({"uniform", "normal"})
_KBINS_ENCODINGS: frozenset[str] = frozenset({"onehot", "onehot-dense", "ordinal"})
_KBINS_STRATEGIES: frozenset[str] = frozenset({"uniform", "quantile", "kmeans"})
# numpy's nine quantile methods, which np.percentile accepts and
# KBinsDiscretizer(strategy="quantile") passes straight through.
_QUANTILE_METHODS: frozenset[str] = frozenset(
    {
        "inverted_cdf",
        "averaged_inverted_cdf",
        "closest_observation",
        "interpolated_inverted_cdf",
        "hazen",
        "weibull",
        "linear",
        "median_unbiased",
        "normal_unbiased",
    }
)


def _boolean(value: object, what: str) -> bool:
    """Validate a flag, refusing the truthy values that are not bools.

    Args:
        value: The value passed for the flag.
        what: What the value is, for the error message.

    Returns:
        The flag.

    Raises:
        TypeError: If the value is not a bool.

    """
    if not isinstance(value, bool):
        raise TypeError(f"{what} must be True or False, got {value!r}")
    return value


def _percentile_range(value: object, what: str) -> tuple[float, float]:
    """Validate a (q_min, q_max) percentile pair.

    Args:
        value: The value passed for ``quantile_range``.
        what: The transformer name, for the error message.

    Returns:
        The pair as floats.

    Raises:
        TypeError: If the value is not a pair of numbers.
        ValueError: If the pair is not ``0 <= q_min <= q_max <= 100``.

    """
    if isinstance(value, str) or not isinstance(value, (list, tuple)) or len(value) != 2:
        raise TypeError(f"{what}: quantile_range must be two percentiles, got {value!r}")
    bounds: list[float] = []
    for bound in value:
        if isinstance(bound, bool) or not isinstance(bound, (int, float)):
            raise TypeError(f"{what}: quantile_range must be two percentiles, got {value!r}")
        bounds.append(float(bound))
    if not 0.0 <= bounds[0] <= bounds[1] <= 100.0:
        raise ValueError(f"{what}: quantile_range must satisfy 0 <= q_min <= q_max <= 100, got {value!r}")
    return bounds[0], bounds[1]


def _numeric_columns(columns: object, what: str) -> list[str] | None:
    """Validate the ``columns`` argument the sklearn.preprocessing ports share.

    Args:
        columns: The value passed for ``columns``; None binds every numeric column.
        what: The transformer name, for the error message.

    Returns:
        The column names, or None.

    Raises:
        TypeError: If columns is a bare string or holds non-strings.
        ValueError: If columns is empty.

    """
    return None if columns is None else _column_list(columns, what)


class RobustScaler(Transformer):
    """Numeric columns -> ``(x - median) / (q_max - q_min)``, in place.

    ``RobustScaler(columns=["price"])`` fits the median of ``price`` and the
    width of its interquartile range, then transforms every value to
    ``(x - center_) / scale_``. Both statistics are taken over the column's
    non-null fit values, so an outlier moves them far less than it moves a
    mean and a standard deviation. A scale below ``10 * f64`` epsilon becomes
    ``1``, so a constant column is centred and not divided — upstream's
    ``_handle_zeros_in_scale``. ``unit_variance=True`` additionally divides
    the scale by ``ppf(q_max / 100) - ppf(q_min / 100)``, the width of the
    same range on a standard normal, so a normally distributed column comes
    out with unit variance; it needs ``0 < q_min < q_max < 100``, because the
    other ranges make that divisor zero or infinite.
    ``with_centering=False`` and ``with_scaling=False`` leave the statistic
    they name unfitted, and the artifact records it as null rather than as a
    neutral number. A null is ignored at fit and passes through at transform,
    which is what scikit-learn's NaN does; a value that is NaN or infinity is
    an error. The column becomes f64 in place, and an integer column is
    widened to f64, so a magnitude past 2^53 rounds. An exact median and
    quantile need every value of a column, so this is the buffered tier with
    ``QuantileEncoder`` and ``GroupAgg``'s ``median``: exact values use
    automatically spillable storage until their ranks are selected or sorted.
    Spilled values use external sorting. With both centering and scaling off,
    fitting validates and counts values without retaining the samples.
    """

    kernel_id: ClassVar[str] = "robust_scale"

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        with_centering: bool = True,
        with_scaling: bool = True,
        quantile_range: Sequence[float] = (25.0, 75.0),
        unit_variance: bool = False,
    ) -> None:
        """Initialize the scaler.

        Args:
            columns: Columns to scale; None scales every integer or float
                column found at fit time.
            with_centering: Subtract the median.
            with_scaling: Divide by the quantile range.
            quantile_range: The (q_min, q_max) percentiles whose width is the
                scale, with ``0 <= q_min <= q_max <= 100``.
            unit_variance: Divide the scale by the width of the same range on
                a standard normal.

        Raises:
            TypeError: If columns, a flag, or a quantile bound has the wrong type.
            ValueError: If columns is empty, the quantile range is not two
                ordered percentiles, or unit_variance is asked for on a range
                that is not strictly inside 0..100.

        """
        self.columns: list[str] | None = _numeric_columns(columns, "RobustScaler")
        self.with_centering: bool = _boolean(with_centering, "RobustScaler: with_centering")
        self.with_scaling: bool = _boolean(with_scaling, "RobustScaler: with_scaling")
        self.unit_variance: bool = _boolean(unit_variance, "RobustScaler: unit_variance")
        self.quantile_range: tuple[float, float] = _percentile_range(quantile_range, "RobustScaler")
        if self.unit_variance and not 0.0 < self.quantile_range[0] < self.quantile_range[1] < 100.0:
            raise ValueError(
                f"RobustScaler: unit_variance needs quantile_range strictly inside 0..100 with q_min < q_max, "
                f"got {tuple(quantile_range)!r}"
            )

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the robust_scale kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "with_centering": self.with_centering,
            "with_scaling": self.with_scaling,
            "quantile_range": list(self.quantile_range),
            "unit_variance": self.unit_variance,
        }

    @property
    def center_(self) -> dict[str, float | None]:
        """The fitted median per column, or None where ``with_centering`` is False.

        Returns:
            Mapping of column name to its centre.

        """
        return self._state()["center"]

    @property
    def scale_(self) -> dict[str, float | None]:
        """The fitted quantile width per column, or None where ``with_scaling`` is False.

        Returns:
            Mapping of column name to its scale.

        """
        return self._state()["scale"]


class QuantileTransformer(Transformer):
    """Numeric columns -> their rank in the fitted distribution, in place.

    ``QuantileTransformer(columns=["price"])`` fits ``n_quantiles`` values per
    column — the percentiles of its non-null fit values at
    ``linspace(0, 100, n_quantiles)`` — against the shared grid
    ``references_ = linspace(0, 1, n_quantiles)``, and ``n_quantiles`` is
    capped at the fit row count as upstream caps it. Transform interpolates a
    value into that grid forwards and backwards and averages the two, so a run
    of equal quantiles answers with the middle of its range rather than one
    end. With ``output_distribution="uniform"`` the result is in ``[0, 1]``:
    the fitted minimum maps to exactly 0, the maximum to exactly 1, and a
    value outside the fitted range is clipped to them, which makes this the
    one scaler that flattens outliers rather than rescaling them. With
    ``"normal"`` the rank is then mapped through the inverse normal CDF and
    clipped to ``+/- ppf(1e-7 - eps)`` so a bound cannot map to infinity, and
    the pinning to 0 and 1 applies within ``1e-7`` of the fitted bounds
    (upstream's ``BOUNDS_THRESHOLD``). A null is ignored at fit and passes
    through at transform, which is what scikit-learn's NaN does; a value that
    is NaN or infinity is an error. The column becomes f64 in place, and an
    integer column is widened to f64. The grid needs every value of a column,
    so exact samples use automatically spillable storage until their ranks
    are fitted. Spilling uses external sorting without subsampling.
    """

    kernel_id: ClassVar[str] = "quantile_transform"

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        n_quantiles: int = 1000,
        output_distribution: str = "uniform",
    ) -> None:
        """Initialize the transformer.

        Args:
            columns: Columns to transform; None transforms every integer or
                float column found at fit time.
            n_quantiles: How many points the fitted grid holds, capped at the
                fit row count.
            output_distribution: "uniform" for a rank in [0, 1], or "normal"
                for that rank mapped through the inverse normal CDF.

        Raises:
            TypeError: If columns or n_quantiles has the wrong type.
            ValueError: If columns is empty, n_quantiles is below 1, or
                output_distribution is not one of the accepted values.

        """
        self.columns: list[str] | None = _numeric_columns(columns, "QuantileTransformer")
        self.n_quantiles: int = _integer(n_quantiles, "QuantileTransformer: n_quantiles")
        if self.n_quantiles < 1:
            raise ValueError(f"QuantileTransformer: n_quantiles must be >= 1, got {n_quantiles!r}")
        self.output_distribution: str = _one_of(
            output_distribution, _OUTPUT_DISTRIBUTIONS, "QuantileTransformer", "output_distribution"
        )

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the quantile_transform kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "n_quantiles": self.n_quantiles,
            "output_distribution": self.output_distribution,
        }

    @property
    def n_quantiles_(self) -> int:
        """How many points the fitted grid actually holds.

        Returns:
            ``min(n_quantiles, fit rows)``, at least 1.

        """
        return len(self._state()["references"])

    @property
    def references_(self) -> list[float]:
        """The shared reference grid, ``linspace(0, 1, n_quantiles_)``.

        Returns:
            The reference quantiles.

        """
        return self._state()["references"]

    @property
    def quantiles_(self) -> dict[str, list[float]]:
        """The fitted values per column, aligned with ``references_``.

        Returns:
            Mapping of column name to its quantile grid.

        """
        return self._state()["quantiles"]


class KBinsDiscretizer(Transformer):
    """Numeric columns -> the bin each value falls in.

    ``KBinsDiscretizer(columns=["price"], n_bins=4)`` fits the bin edges of
    each column and replaces its values with the bin they land in.
    ``strategy="uniform"`` spaces ``n_bins + 1`` edges evenly from the
    column's minimum to its maximum, ``"quantile"`` puts them at the
    percentiles of ``linspace(0, 100, n_bins + 1)`` under ``quantile_method``,
    and ``"kmeans"`` runs 1-D Lloyd's algorithm from a uniform grid and puts
    an edge midway between each pair of sorted cluster centres. Transform
    answers how many interior edges a value is at or past, so a value below
    the first edge is bin 0 and one past the last is the top bin. The
    ``"quantile"`` and ``"kmeans"`` strategies then drop every edge within
    ``1e-8`` of the one before it, so a column can end up with fewer bins than
    ``n_bins`` asked for — exactly as upstream drops them — and a constant
    column is one bin holding everything. ``encode="ordinal"`` replaces the
    column with an i64 bin index in place; ``"onehot"`` and ``"onehot-dense"``
    mean the same thing here, because our output is always dense columns, and
    replace the column with one i64 column per bin named ``<column>_<bin>`` —
    so how many columns there are is known only after the fit and a later step
    in the same pipeline cannot name them. A null is an error, at fit and at
    transform, because upstream refuses one outright; so is a value that is
    NaN or infinity. An integer column is widened to f64, so a magnitude past
    2^53 rounds. ``"quantile"`` and ``"kmeans"`` retain exact samples in
    automatically spillable storage, while ``"uniform"`` needs only the
    extremes and buffers nothing. Spilled k-means makes sequential passes
    while preserving the original statistic and update order.

    ``"kmeans"`` follows upstream's Lloyd iteration down to its empty-cluster
    rules, which decide whole bin layouts on a column with few distinct values:
    a relocated point keeps the label the assignment gave it, a cluster still
    empty afterwards is placed at the biggest cluster's slot as that slot
    stands, and the centres returned are the means the stopping iteration
    computed. What cannot follow is upstream's arbitrary choice among points
    that tie on distance from their centre, which it makes over the rows in
    file order and we make over the sorted buffer; see the parity section of
    the README for the measured residual.

    ``strategy="uniform"`` over a column spanning a few ulps returns bin edges
    that repeat, as ``np.linspace`` and upstream do; the artifact keeps them,
    and the bin between two equal edges is simply empty.
    """

    kernel_id: ClassVar[str] = "k_bins_discretize"

    def __init__(
        self,
        columns: list[str] | None = None,
        *,
        n_bins: int = 5,
        encode: str = "onehot",
        strategy: str = "quantile",
        quantile_method: str = "averaged_inverted_cdf",
    ) -> None:
        """Initialize the discretizer.

        Args:
            columns: Columns to bin; None bins every integer or float column
                found at fit time.
            n_bins: How many bins to ask for, at least 2.
            encode: "ordinal" for one bin-index column, or "onehot" /
                "onehot-dense" for one column per bin.
            strategy: "uniform", "quantile", or "kmeans".
            quantile_method: Which of numpy's nine quantile methods
                ``strategy="quantile"`` uses.

        Raises:
            TypeError: If columns or n_bins has the wrong type.
            ValueError: If columns is empty, n_bins is below 2, or an option
                is not one of the accepted values.

        """
        self.columns: list[str] | None = _numeric_columns(columns, "KBinsDiscretizer")
        self.n_bins: int = _integer(n_bins, "KBinsDiscretizer: n_bins")
        if self.n_bins < 2:
            raise ValueError(f"KBinsDiscretizer: n_bins must be >= 2, got {n_bins!r}")
        self.encode: str = _one_of(encode, _KBINS_ENCODINGS, "KBinsDiscretizer", "encode")
        self.strategy: str = _one_of(strategy, _KBINS_STRATEGIES, "KBinsDiscretizer", "strategy")
        self.quantile_method: str = _one_of(quantile_method, _QUANTILE_METHODS, "KBinsDiscretizer", "quantile_method")

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the k_bins_discretize kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "n_bins": self.n_bins,
            "encode": self.encode,
            "strategy": self.strategy,
            "quantile_method": self.quantile_method,
        }

    @property
    def bin_edges_(self) -> dict[str, list[float]]:
        """The fitted bin edges per column, ascending.

        Returns:
            Mapping of column name to its edges, outer bounds included.

        """
        return self._state()["bin_edges"]

    @property
    def n_bins_(self) -> dict[str, int]:
        """How many bins each column actually has after the too-small ones were dropped.

        Returns:
            Mapping of column name to its bin count.

        """
        return {name: len(edges) - 1 for name, edges in self.bin_edges_.items()}


MAX_OUTPUTS: int = 4096


def _monomial_name(columns: Sequence[str], monomial: tuple[int, ...]) -> str:
    """Name one monomial the way the kernel names it.

    Args:
        columns: The source column names, in the order the expansion uses.
        monomial: The column indices the monomial multiplies, ascending.

    Returns:
        ``a*b`` or ``a^2``, or ``1`` for the empty monomial.

    """
    if not monomial:
        return "1"
    parts: list[str] = []
    for index, group in itertools.groupby(monomial):
        exponent: int = len(list(group))
        parts.append(columns[index] if exponent == 1 else f"{columns[index]}^{exponent}")
    return "*".join(parts)


def _monomial_names(
    columns: Sequence[str], degree: int | tuple[int, int], interaction_only: bool, include_bias: bool
) -> list[str]:
    """Every generated column name, in sklearn's order.

    Args:
        columns: The source column names, in the order the expansion uses.
        degree: The maximum degree, or a (min, max) pair.
        interaction_only: Whether to drop monomials with an exponent above 1.
        include_bias: Whether to prepend the constant column.

    Returns:
        The generated names, in output order.

    Raises:
        ValueError: If the expansion would generate more than MAX_OUTPUTS columns.

    """
    minimum, maximum = (0, degree) if isinstance(degree, int) else degree
    pick = itertools.combinations if interaction_only else itertools.combinations_with_replacement
    names: list[str] = ["1"] if include_bias else []
    for total in range(max(1, minimum), maximum + 1):
        if interaction_only and total > len(columns):
            break
        for monomial in pick(range(len(columns)), total):
            names.append(_monomial_name(columns, monomial))
            if len(names) > MAX_OUTPUTS:
                raise ValueError(
                    f"PolynomialFeatures: {len(columns)} columns of degree {maximum} would generate more than "
                    f"the {MAX_OUTPUTS} columns allowed"
                )
    return names


class PolynomialFeatures(Transformer):
    """Numeric columns -> one column per monomial of them, replacing them.

    ``PolynomialFeatures(columns=["price", "height"])`` replaces the two
    columns with ``1``, ``price``, ``height``, ``price^2``, ``price*height``
    and ``height^2``: every monomial of total degree at most ``degree`` over
    the listed columns, in scikit-learn's order — the bias first, then degree
    by degree, and within a degree by the order ``columns`` gives.
    ``degree=(min, max)`` keeps only the degrees in that range (the bias
    survives either way), and ``interaction_only=True`` drops every monomial
    with an exponent above 1, leaving the products of distinct columns.

    The width is a function of the parameters alone, so this transformer
    never fits: it declares its outputs before any data is read, and a later
    step in the same pipeline can name them. scikit-learn writes a product as
    ``price height``; a space is a poor column name, so ours is
    ``price*height``, and a source column whose name holds ``*``, ``^`` or a
    space is refused rather than generating a name nothing could parse. The
    bias column is named ``1``, as scikit-learn names it.

    Every factor is multiplied in scikit-learn's own order, so the products
    agree bit for bit. A null factor makes the monomial null; the bias has no
    factors and stays 1. Outputs are f64 whatever the inputs are; an integer
    column is read exactly or refused, and ``sparse_output`` and ``order``
    have no counterpart because our output is always dense columns.

    A product that overflows to an infinity is an error naming the monomial,
    in both transform paths, rather than a column the next numeric step would
    refuse to read: ``a^2`` for ``a = 1e200`` raises where scikit-learn writes
    ``inf``.
    """

    kernel_id: ClassVar[str] = "polynomial_features"

    def __init__(
        self,
        columns: list[str],
        *,
        degree: int | tuple[int, int] = 2,
        interaction_only: bool = False,
        include_bias: bool = True,
    ) -> None:
        """Initialize the expansion.

        Args:
            columns: Columns to expand, in the order the monomials use; none
                of them survives to the output.
            degree: The maximum total degree, or a ``(min, max)`` pair of
                non-negative integers with ``min <= max``.
            interaction_only: Keep only products of distinct columns.
            include_bias: Prepend a constant column of ones named ``1``.

        Raises:
            TypeError: If columns is a bare string, degree is not an integer
                or a pair of them, or a flag is not a bool.
            ValueError: If columns is empty, a column name would make a
                generated name ambiguous, degree is negative or inverted,
                degree 0 is asked for without a bias, or the expansion would
                be wider than ``MAX_OUTPUTS``.

        """
        self.columns: list[str] = _column_list(columns, "PolynomialFeatures")
        for column in self.columns:
            if set(column) & {"*", "^", " "}:
                raise ValueError(
                    f"PolynomialFeatures: column {column!r} holds one of '*', '^' or a space, "
                    "which would make a generated name ambiguous"
                )
        self.degree: int | tuple[int, int] = _degree(degree)
        if not isinstance(interaction_only, bool):
            raise TypeError(f"PolynomialFeatures: interaction_only must be True or False, got {interaction_only!r}")
        if not isinstance(include_bias, bool):
            raise TypeError(f"PolynomialFeatures: include_bias must be True or False, got {include_bias!r}")
        self.interaction_only: bool = interaction_only
        self.include_bias: bool = include_bias
        maximum: int = self.degree if isinstance(self.degree, int) else self.degree[1]
        if maximum == 0 and not include_bias:
            raise ValueError("PolynomialFeatures: degree 0 with include_bias False would generate no columns")
        _monomial_names(self.columns, self.degree, self.interaction_only, self.include_bias)

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the polynomial_features kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "degree": self.degree if isinstance(self.degree, int) else list(self.degree),
            "interaction_only": self.interaction_only,
            "include_bias": self.include_bias,
        }

    @property
    def output_columns(self) -> list[str]:
        """The columns this expansion writes, in output order.

        Known from the parameters alone, before any fit, because the width is
        a function of the column count and the degree.

        Returns:
            The generated column names.

        """
        return _monomial_names(self.columns, self.degree, self.interaction_only, self.include_bias)


def _degree(degree: object) -> int | tuple[int, int]:
    """Validate a polynomial degree: an integer, or a (min, max) pair.

    Args:
        degree: The value passed for ``degree``.

    Returns:
        The degree as an int or a pair of ints.

    Raises:
        TypeError: If the value is neither an integer nor a pair of them.
        ValueError: If a bound is negative or min exceeds max.

    """
    if isinstance(degree, (list, tuple)):
        if len(degree) != 2:
            raise TypeError(f"PolynomialFeatures: degree must be an integer or a (min, max) pair, got {degree!r}")
        low: int = _integer(degree[0], "PolynomialFeatures: degree")
        high: int = _integer(degree[1], "PolynomialFeatures: degree")
        if low < 0 or high < 0:
            raise ValueError(f"PolynomialFeatures: degree must not be negative, got {degree!r}")
        if low > high:
            raise ValueError(f"PolynomialFeatures: degree must have min <= max, got {degree!r}")
        return (low, high)
    value: int = _integer(degree, "PolynomialFeatures: degree")
    if value < 0:
        raise ValueError(f"PolynomialFeatures: degree must not be negative, got {degree!r}")
    return value


_EXTRAPOLATION: frozenset[str] = frozenset({"error", "constant", "linear", "continue", "periodic"})
_SPLINE_MISSING: frozenset[str] = frozenset({"error", "zeros"})


class SplineTransformer(Transformer):
    """Numeric columns -> a B-spline basis per column, from fitted knots.

    ``SplineTransformer(columns=["hour"], n_knots=5, degree=3)`` replaces
    ``hour`` with ``hour_sp_0`` through ``hour_sp_6``: the
    ``n_knots + degree - 1`` B-spline basis functions of that degree over
    knots fitted to the column. ``knots="uniform"`` places them at
    ``linspace(min, max, n_knots)``, which is a min/max monoid;
    ``knots="quantile"`` places them at the percentiles of the whole column,
    retaining exact values in automatically spillable storage until the
    merged ranks are selected or externally sorted, as for ``GroupAgg``'s median.
    ``degree`` further knots are added beyond each end, spaced like the two
    knots at that end, and the basis is the Cox-de Boor recursion over that
    vector.

    A generated basis value that is not finite — which ``"continue"`` reaches
    far outside the fitted range, and a knot vector spaced by a denormal
    reaches inside it — is an error naming the generated column, in both
    transform paths, rather than an ``inf`` the next numeric step would refuse
    to read.

    ``extrapolation`` says what happens outside the fitted range:
    ``"error"`` refuses the value, ``"constant"`` holds the boundary basis
    values, ``"linear"`` continues them along the boundary derivative,
    ``"continue"`` evaluates the boundary polynomial pieces on, and
    ``"periodic"`` wraps the column onto the interval between the first and
    last knot (which needs ``degree < n_knots`` and gives ``n_knots - 1``
    columns). ``include_bias=False`` drops the last basis function per
    column. ``handle_missing="error"`` refuses a null, at transform as well
    as at fit; ``"zeros"`` encodes it as zeros in every generated column.

    The width comes from the parameters alone even though the knot positions
    are fitted, so a later step in the same pipeline can name the outputs.
    ``sparse_output`` and ``order`` have no counterpart because our output is
    always dense columns, and ``knots`` as an explicit array is not accepted:
    our knots are always fitted.
    """

    kernel_id: ClassVar[str] = "spline_transform"

    def __init__(
        self,
        columns: list[str],
        *,
        n_knots: int = 5,
        degree: int = 3,
        knots: str = "uniform",
        extrapolation: str = "constant",
        include_bias: bool = True,
        handle_missing: str = "error",
    ) -> None:
        """Initialize the transformer.

        Args:
            columns: Columns to expand; none of them survives to the output.
            n_knots: How many knots to fit per column, from 2 to MAX_OUTPUTS.
            degree: The polynomial degree of the basis, from 0 to MAX_OUTPUTS.
            knots: Where to put them: "uniform" (min to max) or "quantile".
            extrapolation: What a value outside the fitted range becomes:
                "error", "constant", "linear", "continue" or "periodic".
            include_bias: Keep the last basis function per column.
            handle_missing: What a null becomes: "error" or "zeros".

        Raises:
            TypeError: If columns is a bare string, a count is not an
                integer, or include_bias is not a bool.
            ValueError: If columns is empty, a count is out of range, an
                option is not one of the accepted values,
                periodic extrapolation is asked for with degree at or above
                n_knots, the combination generates no columns at all, or the
                expansion would be wider than ``MAX_OUTPUTS``.

        """
        self.columns: list[str] = _column_list(columns, "SplineTransformer")
        self.n_knots: int = _integer(n_knots, "SplineTransformer: n_knots")
        if not 2 <= self.n_knots <= MAX_OUTPUTS:
            raise ValueError(f"SplineTransformer: n_knots must be between 2 and {MAX_OUTPUTS}, got {n_knots!r}")
        self.degree: int = _integer(degree, "SplineTransformer: degree")
        if not 0 <= self.degree <= MAX_OUTPUTS:
            raise ValueError(f"SplineTransformer: degree must be between 0 and {MAX_OUTPUTS}, got {degree!r}")
        self.knots: str = _one_of(knots, frozenset({"uniform", "quantile"}), "SplineTransformer", "knots")
        self.extrapolation: str = _one_of(extrapolation, _EXTRAPOLATION, "SplineTransformer", "extrapolation")
        if not isinstance(include_bias, bool):
            raise TypeError(f"SplineTransformer: include_bias must be True or False, got {include_bias!r}")
        self.include_bias: bool = include_bias
        self.handle_missing: str = _one_of(handle_missing, _SPLINE_MISSING, "SplineTransformer", "handle_missing")
        if self.extrapolation == "periodic" and self.n_knots <= self.degree:
            raise ValueError(
                "SplineTransformer: periodic extrapolation needs degree below n_knots, got "
                f"n_knots {self.n_knots} and degree {self.degree}"
            )
        if self.splines < 1:
            raise ValueError(
                f"SplineTransformer: n_knots {self.n_knots}, degree {self.degree}, extrapolation "
                f"{self.extrapolation!r} and include_bias {self.include_bias} generate no columns at all"
            )
        if self.splines * len(self.columns) > MAX_OUTPUTS:
            raise ValueError(
                f"SplineTransformer: {len(self.columns)} columns of {self.splines} splines would generate more "
                f"than the {MAX_OUTPUTS} columns allowed"
            )

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the spline_transform kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {
            "columns": self.columns,
            "n_knots": self.n_knots,
            "degree": self.degree,
            "knots": self.knots,
            "extrapolation": self.extrapolation,
            "include_bias": self.include_bias,
            "handle_missing": self.handle_missing,
        }

    @property
    def splines(self) -> int:
        """How many columns each input column becomes.

        Returns:
            ``n_knots + degree - 1`` (``n_knots - 1`` when periodic), one
            fewer without a bias.

        """
        total: int = self.n_knots - 1 if self.extrapolation == "periodic" else self.n_knots + self.degree - 1
        return total - (0 if self.include_bias else 1)

    @property
    def output_columns(self) -> list[str]:
        """The columns this transformer writes, in output order.

        Known from the parameters alone, before any fit; only the knot
        positions are fitted.

        Returns:
            The generated column names.

        """
        return [f"{column}_sp_{index}" for column in self.columns for index in range(self.splines)]

    @property
    def knots_(self) -> dict[str, list[float]]:
        """The fitted base knots per column, ascending.

        Returns:
            Mapping of column name to its ``n_knots`` knot positions.

        """
        return self._state()["knots"]


class PowerTransformer(Transformer):
    """Numeric columns -> the power of them that is most Gaussian, in place.

    ``PowerTransformer(columns=["price"])`` fits one ``lambda`` per column by
    maximising the profile log-likelihood of the transformed column, then
    applies it: Yeo-Johnson takes any value, Box-Cox needs strictly positive
    data and refuses anything else, at transform as well as at fit. Box-Cox
    also refuses a constant column, whose likelihood has no maximum;
    Yeo-Johnson leaves one at ``lambda = 1``, the identity, as scikit-learn
    does.

    ``standardize=True`` then centres and scales each transformed column by
    its own mean and standard deviation. A null teaches nothing and passes
    through as a null, which is how scikit-learn treats a NaN.

    The solver is scipy's: Box-Cox brackets ``(-2, 2)`` and runs Brent's
    method, Yeo-Johnson runs Brent's method bounded by the interval scipy
    derives from the column's magnitude, both on scipy's own objective and at
    its own tolerance. This is the buffered, iterative tier: exact inputs,
    cached logs for either method, and reusable objective scratch can all
    spill to disk. Each objective makes several sequential passes, so spilling
    trades sample RAM for repeated I/O. After solving, standardization rewrites
    the owned input storage and makes three statistic passes without another
    transformed copy. Solver arithmetic and stopping rules are unchanged.

    Every sum is exact, so the fitted lambda does not depend on how the rows
    were split — but it is the one port whose values are compared against
    scikit-learn with a tolerance rather than exactly, because the last bits
    of the objective decide where a flat optimum lands. ``lambdas_`` is one
    maximiser of a flat likelihood, not a reproducible statistic: on a
    near-constant or very large column it can differ from scikit-learn's by
    100 or more, and the transformed values are then unbounded against
    upstream's, absolutely and relatively alike. The parity section of the
    README says what was measured and where it stops holding.
    """

    kernel_id: ClassVar[str] = "power_transform"

    def __init__(self, columns: list[str], *, method: str = "yeo-johnson", standardize: bool = True) -> None:
        """Initialize the transformer.

        Args:
            columns: Columns to transform, in place.
            method: "yeo-johnson" (any value) or "box-cox" (strictly positive).
            standardize: Centre and scale each transformed column.

        Raises:
            TypeError: If columns is a bare string or standardize is not a bool.
            ValueError: If columns is empty or method is not one of the
                accepted values.

        """
        self.columns: list[str] = _column_list(columns, "PowerTransformer")
        self.method: str = _one_of(method, frozenset({"yeo-johnson", "box-cox"}), "PowerTransformer", "method")
        if not isinstance(standardize, bool):
            raise TypeError(f"PowerTransformer: standardize must be True or False, got {standardize!r}")
        self.standardize: bool = standardize

    def params(self) -> dict[str, Any]:
        """Kernel parameters for the power_transform kernel.

        Returns:
            The declarative parameter mapping.

        """
        return {"columns": self.columns, "method": self.method, "standardize": self.standardize}

    @property
    def lambdas_(self) -> dict[str, float]:
        """The fitted power per column.

        Returns:
            Mapping of column name to its lambda.

        """
        return self._state()["lambdas"]

    @property
    def means_(self) -> dict[str, float] | None:
        """The mean of each transformed column, or None without standardize.

        Returns:
            Mapping of column name to the centre subtracted at transform.

        """
        return self._state()["means"]

    @property
    def scales_(self) -> dict[str, float] | None:
        """The standard deviation of each transformed column, or None without standardize.

        Returns:
            Mapping of column name to the scale divided out at transform.

        """
        return self._state()["scales"]
